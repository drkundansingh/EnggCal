// Offline app-shell cache.
//
// WHY THIS WAS REWRITTEN
// The previous version was cache-first for EVERYTHING and used a hardcoded
// cache name. That combination meant a deployed update was never picked up:
// once index.html and app.js were in the cache they were served forever, a
// normal refresh did nothing, and because the cache name never changed the
// cleanup in `activate` never ran either. Users were pinned to whatever
// version they first loaded.
//
// STRATEGY NOW
//   - Code and data (HTML, JS, CSS, JSON): NETWORK-FIRST. Always try the
//     network so a deploy is picked up on the next load; fall back to cache
//     only when genuinely offline. This is the fix for the stale-site bug.
//   - Static assets (images, fonts): CACHE-FIRST. They rarely change and
//     are the expensive part of an offline load.
//   - BUILD_ID is stamped at build time, so every deploy gets a fresh cache
//     and the previous one is deleted on activate.

const BUILD_ID = '20261017180212';           // replaced during build
const CACHE_NAME = 'enghub-' + BUILD_ID;

const SHELL_FILES = [
  './index.html',
  './css/styles.css',
  './js/app.js',
  './data/formulaLibrary.json',
  './data/content-visibility.json',
  './manifest.webmanifest',
  './assets/logo.png',
];

// Extensions served cache-first: they change rarely and are heavy.
const STATIC_RE = /\.(png|jpg|jpeg|gif|svg|webp|ico|woff2?|ttf|eot)$/i;

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(SHELL_FILES))
      .catch(() => {
        // A missing shell file shouldn't block install entirely —
        // partial offline support beats none.
      })
  );
  // Deliberately NOT calling self.skipWaiting() here. For a genuinely new
  // installation (no existing worker controlling the page) this changes
  // nothing — the browser activates it immediately regardless, since
  // there's nothing to wait for. But when an OLD worker is already
  // controlling the page, skipping here means the new one activates and
  // claims every open tab within a fraction of a second, wiping out the
  // "update available" banner (see app.js) before a person can even read
  // it, let alone click it. The page's "Update now" button sends a
  // SKIP_WAITING message (handled below) once the person actually chooses
  // to update — that is the only path that should trigger it.
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(
        // Delete every cache from a previous build.
        keys.filter((k) => k.indexOf('enghub-') === 0 && k !== CACHE_NAME)
            .map((k) => caches.delete(k))
      ))
      .then(() => self.clients.claim())
  );
});

// Allow the page to tell a waiting worker to take over right away.
self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  let url;
  try { url = new URL(req.url); } catch (e) { return; }
  if (url.origin !== location.origin) return;   // let cross-origin through

  if (STATIC_RE.test(url.pathname)) {
    // CACHE-FIRST for images and fonts.
    event.respondWith(
      caches.match(req).then((cached) => cached || fetch(req).then((res) => {
        if (res.ok) {
          const copy = res.clone();
          caches.open(CACHE_NAME).then((c) => c.put(req, copy));
        }
        return res;
      }))
    );
    return;
  }

  // NETWORK-FIRST for navigations, HTML, JS, CSS and JSON — this is what
  // makes a new deploy show up instead of the old cached copy.
  //
  // { cache: 'no-store' } here is deliberate and important: a plain
  // fetch(req) is STILL subject to the browser's own HTTP cache (governed
  // by whatever Cache-Control headers the host sends) even inside a
  // service worker — "network-first" in the JS logic doesn't guarantee an
  // actual network round-trip unless the browser's HTTP cache is
  // explicitly bypassed too. Without this, a returning visitor within the
  // host's cache window could still see stale content despite this
  // strategy being correctly written.
  event.respondWith(
    fetch(req, { cache: 'no-store' })
      .then((res) => {
        if (res.ok) {
          const copy = res.clone();
          caches.open(CACHE_NAME).then((c) => c.put(req, copy));
        }
        return res;
      })
      .catch(() =>
        // Offline: serve the cached copy, falling back to the shell for
        // navigations so the app still opens with no connection.
        caches.match(req).then((cached) =>
          cached || (req.mode === 'navigate' ? caches.match('./index.html') : undefined)
        )
      )
  );
});
