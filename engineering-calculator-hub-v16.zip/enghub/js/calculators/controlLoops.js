// controlLoops.js — the major control loops of a thermal power plant,
// defined as node/edge graphs so they can be drawn and animated.
//
// Every loop structure here is taken from published control-engineering
// descriptions, not invented. Sources are named per loop in `sources`.
// Setpoint VALUES are illustrative starting points for the simulation —
// real setpoints are plant-specific and come from the unit's own design
// documents. The STRUCTURE (what feeds what, which blocks exist, cascade
// vs feedforward vs select) is the part that is genuinely standard.
//
// Node types drive how each block is drawn:
//   sensor      — a measurement (transmitter)
//   controller  — a PID block
//   compute     — a function block (sum, multiply, select, ratio, f(x))
//   actuator    — a final control element (valve, damper, drive)
//   process     — the physical process being controlled
//   demand      — an external demand/setpoint input

import { Lag, DeadTime, Integrator, RateLimit, PID, InverseResponse, clamp } from './loopDynamics.js';
import * as steam from './steamTable.js';

export const LOOP_IDS = [
  'drum-level-3e',
  'combustion-cross-limit',
  'steam-temp-cascade',
  'mill-control',
  'furnace-draft',
  'coordinated-master',
  'turbine-bypass',
  'deaerator-level',
  'hp-heater-level',
  'condenser-hotwell',
  'avr-excitation',
  'firewater-ratio',
  'sliding-pressure',
  'condenser-vacuum',
];

export const CONTROL_LOOPS = {

  // ------------------------------------------------------------------
  'drum-level-3e': {
    name: 'Three-Element Drum Level Control',
    system: 'Feedwater',
    difficulty: 'Core',
    why: 'The single most important — and most misunderstood — loop on a drum boiler. Level must be held tight: too low uncovers tubes and overheats them, too high carries water into the turbine.',
    problem: 'Shrink and swell. When steam demand suddenly rises, drum pressure drops, steam bubbles expand, and the level appears to RISE even though the boiler is actually losing water. A naive level controller reads "high level" and closes the feedwater valve — exactly the wrong action, at exactly the wrong moment.',
    solution: 'Feed the steam flow FORWARD into the level loop so the controller anticipates the demand change instead of reacting to a misleading level signal, and CASCADE the level controller onto a fast feedwater flow loop so supply-pressure disturbances are caught before they ever affect level.',
    elements: [
      'Element 1 — Drum level (the controlled variable)',
      'Element 2 — Steam flow (the disturbance, fed forward)',
      'Element 3 — Feedwater flow (the fast inner loop)',
    ],
    nodes: [
      { id: 'lt', type: 'sensor', label: 'LT', sub: 'Drum level', x: 60, y: 60 },
      { id: 'ft-steam', type: 'sensor', label: 'FT', sub: 'Steam flow', x: 60, y: 155 },
      { id: 'ft-fw', type: 'sensor', label: 'FT', sub: 'Feedwater flow', x: 60, y: 250 },
      { id: 'lic', type: 'controller', label: 'LIC', sub: 'Level PID (master)', x: 215, y: 60 },
      { id: 'sum', type: 'compute', label: 'Σ', sub: 'Level MV + steam FF', x: 375, y: 105 },
      { id: 'fic', type: 'controller', label: 'FIC', sub: 'Flow PID (slave)', x: 530, y: 155 },
      { id: 'fcv', type: 'actuator', label: 'FCV', sub: 'Feedwater valve', x: 690, y: 155 },
      { id: 'drum', type: 'process', label: 'DRUM', sub: 'Steam drum', x: 690, y: 60 },
    ],
    edges: [
      { from: 'lt', to: 'lic', label: 'PV' },
      { from: 'lic', to: 'sum', label: 'MV' },
      { from: 'ft-steam', to: 'sum', label: 'feedforward', style: 'ff' },
      { from: 'sum', to: 'fic', label: 'SP (cascade)', style: 'cascade' },
      { from: 'ft-fw', to: 'fic', label: 'PV' },
      { from: 'fic', to: 'fcv', label: 'MV' },
      { from: 'fcv', to: 'drum', label: 'feedwater' },
      { from: 'drum', to: 'lt', label: 'level', style: 'feedback' },
    ],
    // Live simulation: how the loop responds to a steam demand change.
    sim: {
      inputLabel: 'Steam demand (% MCR)',
      inputMin: 20, inputMax: 100, inputDefault: 60,
      run(steamDemand) {
        // Shrink/swell: a step up in demand transiently swells the level.
        const swell = (steamDemand - 60) * 0.06;
        const levelPV = 0 + swell;
        const levelSP = 0;
        // Level PID trims; steam flow feeds forward as the bulk demand.
        const levelTrim = (levelSP - levelPV) * 1.8;
        const ffDemand = steamDemand;
        const fwSP = Math.max(0, ffDemand + levelTrim);
        const fwPV = fwSP * 0.98; // slave loop tracks closely
        const valve = Math.min(100, Math.max(0, fwSP * 0.95));
        return {
          nodeValues: {
            'lt': `${levelPV >= 0 ? '+' : ''}${levelPV.toFixed(0)} mm`,
            'ft-steam': `${steamDemand.toFixed(0)} %`,
            'ft-fw': `${fwPV.toFixed(0)} %`,
            'lic': `trim ${levelTrim >= 0 ? '+' : ''}${levelTrim.toFixed(1)}`,
            'sum': `${fwSP.toFixed(0)} %`,
            'fic': `err ${(fwSP - fwPV).toFixed(1)}`,
            'fcv': `${valve.toFixed(0)} % open`,
            'drum': `${levelPV >= 0 ? '+' : ''}${levelPV.toFixed(0)} mm`,
          },
          insight: Math.abs(swell) > 1.5
            ? `Steam demand moved away from normal, so the drum level is showing ${swell > 0 ? 'SWELL (reads high)' : 'SHRINK (reads low)'}. Notice the feedwater demand still follows steam flow through the feedforward path — a single-element controller would be ${swell > 0 ? 'closing' : 'opening'} the valve right now, which is backwards.`
            : 'Steady load. Level is on setpoint and feedwater flow matches steam flow — the level PID is only trimming for small errors.',
        };
      },
    },
    sources: [
      'Yokogawa/MG SC200 three-element drum level application note (cascade + feedforward structure)',
      'Cross Company — Three Element Drum Level Control',
      'WARE — 3-Element Steam Drum Level Control (shrink/swell explanation)',
    ],
  },

  // ------------------------------------------------------------------
  'combustion-cross-limit': {
    name: 'Combustion Control with Cross-Limiting',
    system: 'Boiler / Firing',
    difficulty: 'Advanced',
    why: 'This is the loop that keeps the furnace from ever running fuel-rich. It is a safety architecture as much as a control strategy.',
    problem: 'If fuel increases before air does, the furnace goes fuel-rich — incomplete combustion, unburnt fuel accumulating in the furnace, and a genuine explosion hazard. If air lags on the way down, you waste heat up the stack.',
    solution: 'Cross-limiting. A HIGH select on the air demand and a LOW select on the fuel demand mean air always LEADS fuel on a load increase, and fuel always LEADS air on a load decrease. The furnace physically cannot go fuel-rich through normal control action — the selectors make it structurally impossible, not merely unlikely.',
    elements: [
      'Air leads on the way UP (high select on air)',
      'Fuel leads on the way DOWN (low select on fuel)',
      'O₂ trim fine-tunes the ratio for efficiency',
    ],
    nodes: [
      { id: 'master', type: 'demand', label: 'BOILER MASTER', sub: 'Firing rate demand', x: 60, y: 150 },
      { id: 'hs', type: 'compute', label: 'HIGH<br/>SELECT', sub: 'Air demand', x: 250, y: 70 },
      { id: 'ls', type: 'compute', label: 'LOW<br/>SELECT', sub: 'Fuel demand', x: 250, y: 240 },
      { id: 'ratio', type: 'compute', label: '×', sub: 'Air/fuel ratio', x: 400, y: 70 },
      { id: 'o2', type: 'controller', label: 'O₂ TRIM', sub: 'Excess air PID', x: 400, y: 300 },
      { id: 'aic', type: 'controller', label: 'AIC', sub: 'Air flow PID', x: 555, y: 70 },
      { id: 'fic', type: 'controller', label: 'FIC', sub: 'Fuel flow PID', x: 555, y: 240 },
      { id: 'damper', type: 'actuator', label: 'FD FAN', sub: 'Damper / IGV', x: 710, y: 70 },
      { id: 'feeder', type: 'actuator', label: 'FEEDER', sub: 'Coal / fuel valve', x: 710, y: 240 },
      { id: 'ft-air', type: 'sensor', label: 'FT', sub: 'Air flow', x: 555, y: 150 },
      { id: 'ft-fuel', type: 'sensor', label: 'FT', sub: 'Fuel flow', x: 555, y: 320 },
    ],
    edges: [
      { from: 'master', to: 'hs', label: 'demand' },
      { from: 'master', to: 'ls', label: 'demand' },
      { from: 'ft-fuel', to: 'hs', label: 'fuel flow (cross-limit)', style: 'crosslimit' },
      { from: 'ft-air', to: 'ls', label: 'air flow (cross-limit)', style: 'crosslimit' },
      { from: 'hs', to: 'ratio', label: '' },
      { from: 'o2', to: 'ratio', label: 'trim', style: 'ff' },
      { from: 'ratio', to: 'aic', label: 'SP' },
      { from: 'ls', to: 'fic', label: 'SP' },
      { from: 'ft-air', to: 'aic', label: 'PV', style: 'feedback' },
      { from: 'ft-fuel', to: 'fic', label: 'PV', style: 'feedback' },
      { from: 'aic', to: 'damper', label: 'MV' },
      { from: 'fic', to: 'feeder', label: 'MV' },
    ],
    sim: {
      inputLabel: 'Firing rate demand (%)',
      inputMin: 30, inputMax: 100, inputDefault: 70,
      run(demand, prev = 70) {
        const rising = demand > prev;
        // Cross-limiting: air demand = max(demand, fuel flow); fuel = min(demand, air flow)
        const fuelFlow = rising ? prev : demand;
        const airFlow = rising ? demand : prev;
        const airDemand = Math.max(demand, fuelFlow);
        const fuelDemand = Math.min(demand, airFlow);
        return {
          nodeValues: {
            'master': `${demand.toFixed(0)} %`,
            'hs': `${airDemand.toFixed(0)} %`,
            'ls': `${fuelDemand.toFixed(0)} %`,
            'ratio': `${(airDemand * 1.15).toFixed(0)} %`,
            'o2': `3.2 % O₂`,
            'aic': `SP ${(airDemand * 1.15).toFixed(0)}`,
            'fic': `SP ${fuelDemand.toFixed(0)}`,
            'damper': `${Math.min(100, airDemand * 1.05).toFixed(0)} %`,
            'feeder': `${fuelDemand.toFixed(0)} %`,
            'ft-air': `${airFlow.toFixed(0)} %`,
            'ft-fuel': `${fuelFlow.toFixed(0)} %`,
          },
          insight: `Air demand is the HIGHER of (firing demand, actual fuel flow) = ${airDemand.toFixed(0)}%. Fuel demand is the LOWER of (firing demand, actual air flow) = ${fuelDemand.toFixed(0)}%. Whichever way the load moves, air is always on the safe side of fuel — that is the whole point of the two selectors.`,
        };
      },
    },
    sources: [
      'Yokogawa YS1700 Boiler Combustion Control application note (high/low select cross-limiting)',
      'Control Guru — Ratio with Cross-Limiting Override Control of a Combustion Process',
      'MG SC200 ratio with cross-limiting override application note',
    ],
  },

  // ------------------------------------------------------------------
  'steam-temp-cascade': {
    name: 'Superheater Steam Temperature (Cascade Attemperation)',
    system: 'Steam',
    difficulty: 'Advanced',
    why: 'Steam temperature must be held within a narrow band: too high damages superheater tubes and the turbine, too low risks moisture in the last turbine stages and costs efficiency.',
    problem: 'The superheater is a huge thermal mass. Spray water added at the attemperator takes a long time to show up as a temperature change at the outlet — a long dead time and lag that makes a single PID loop either sluggish or unstable.',
    solution: 'Cascade. An outer (master) PID watches the final superheater outlet temperature and sets the target for an inner (slave) PID that watches the temperature right AFTER the spray nozzle. The inner loop sees spray changes almost immediately, so it absorbs the disturbance long before the outer loop would have noticed.',
    elements: [
      'Master PID — final SH outlet temperature (slow, accurate)',
      'Slave PID — attemperator outlet temperature (fast, responsive)',
      'Saturation-temperature limit — protects against spraying below saturation',
    ],
    nodes: [
      { id: 'tt-out', type: 'sensor', label: 'TT', sub: 'Final SH outlet temp', x: 60, y: 60 },
      { id: 'tic-master', type: 'controller', label: 'TIC-M', sub: 'Master PID', x: 225, y: 60 },
      { id: 'maxsel', type: 'compute', label: 'MAX<br/>SELECT', sub: 'vs sat. temp limit', x: 390, y: 60 },
      { id: 'satcalc', type: 'compute', label: 'f(x)', sub: 'Sat. temp from pressure', x: 390, y: 155 },
      { id: 'tic-slave', type: 'controller', label: 'TIC-S', sub: 'Slave PID', x: 555, y: 60 },
      { id: 'tt-spray', type: 'sensor', label: 'TT', sub: 'After spray nozzle', x: 555, y: 155 },
      { id: 'spray', type: 'actuator', label: 'SPRAY<br/>VALVE', sub: 'Attemperator', x: 710, y: 60 },
      { id: 'sh', type: 'process', label: 'SUPER<br/>HEATER', sub: 'Thermal mass + lag', x: 710, y: 250 },
    ],
    edges: [
      { from: 'tt-out', to: 'tic-master', label: 'PV' },
      { from: 'tic-master', to: 'maxsel', label: 'MV' },
      { from: 'satcalc', to: 'maxsel', label: 'min limit', style: 'ff' },
      { from: 'maxsel', to: 'tic-slave', label: 'SP (cascade)', style: 'cascade' },
      { from: 'tt-spray', to: 'tic-slave', label: 'PV' },
      { from: 'tic-slave', to: 'spray', label: 'MV' },
      { from: 'spray', to: 'sh', label: 'spray water' },
      { from: 'sh', to: 'tt-out', label: 'outlet temp', style: 'feedback' },
    ],
    sim: {
      inputLabel: 'Final SH outlet temperature (°C)',
      inputMin: 520, inputMax: 580, inputDefault: 540,
      run(outletTemp) {
        const sp = 540;
        const err = outletTemp - sp;
        const masterMV = 300 + err * 2.5; // slave SP, °C after spray
        const satTemp = 340; // illustrative saturation temperature limit
        const slaveSP = Math.max(satTemp, masterMV);
        const limited = masterMV < satTemp;
        const sprayPct = Math.min(100, Math.max(0, 30 + err * 4));
        return {
          nodeValues: {
            'tt-out': `${outletTemp.toFixed(0)} °C`,
            'tic-master': `err ${err >= 0 ? '+' : ''}${err.toFixed(0)} °C`,
            'satcalc': `${satTemp} °C`,
            'maxsel': `${slaveSP.toFixed(0)} °C`,
            'tic-slave': `SP ${slaveSP.toFixed(0)} °C`,
            'tt-spray': `${(slaveSP - 2).toFixed(0)} °C`,
            'spray': `${sprayPct.toFixed(0)} % open`,
            'sh': `${outletTemp.toFixed(0)} °C`,
          },
          insight: limited
            ? `The master is asking for an attemperator outlet BELOW saturation temperature (${satTemp} °C). The MAX select has clamped it — this is the protection that stops the spray from putting water, not steam, into the superheater.`
            : err > 3
              ? 'Outlet temperature is above setpoint, so the master is driving the slave setpoint down and the spray valve is opening. Note the slave reacts to the spray almost immediately, while the outlet temperature will take minutes to follow.'
              : err < -3
                ? 'Outlet is below setpoint — spray is being cut back. Watch that the slave loop responds first; the outlet only catches up after the superheater thermal lag.'
                : 'On setpoint. The cascade is holding, with the slave loop absorbing small spray-water disturbances before they ever reach the outlet.',
        };
      },
    },
    sources: [
      'ScienceDirect — superheated steam temperature control (two-stage attemperation, cascade with saturation-temperature max select)',
      'HRSG superheater cascade control study (arXiv 2512.00990)',
      'InstrumentationTools — Superheated Steam Temperature Control System',
    ],
  },

  // ------------------------------------------------------------------
  'furnace-draft': {
    name: 'Furnace Draft Control',
    system: 'Air & Flue Gas',
    difficulty: 'Core',
    why: 'The furnace must be held at a slight negative pressure. Positive pressure blows hot flue gas and flame out of inspection doors; too negative risks implosion of the furnace casing.',
    problem: 'The ID fan and FD fan are fighting over the same furnace. Change the FD fan for combustion air, and the furnace pressure moves — a strong, fast interaction between two separate control loops.',
    solution: 'Feedforward coupling. The FD fan (air flow) demand is fed forward directly into the ID fan demand, so the ID fan starts moving at the same instant the FD fan does, rather than waiting for the pressure error to appear. The draft PID then only has to trim the small residual.',
    elements: [
      'Furnace pressure PID (the trim)',
      'Air flow feedforward from the FD fan (the bulk action)',
      'ID fan damper / IGV / VFD as final element',
    ],
    nodes: [
      { id: 'pt', type: 'sensor', label: 'PT', sub: 'Furnace pressure', x: 60, y: 70 },
      { id: 'pic', type: 'controller', label: 'PIC', sub: 'Draft PID', x: 235, y: 70 },
      { id: 'ff-air', type: 'demand', label: 'FD FAN<br/>DEMAND', sub: 'Air flow feedforward', x: 235, y: 190 },
      { id: 'sum', type: 'compute', label: 'Σ', sub: 'FF + trim', x: 425, y: 130 },
      { id: 'idfan', type: 'actuator', label: 'ID FAN', sub: 'Damper / IGV / VFD', x: 610, y: 130 },
      { id: 'furnace', type: 'process', label: 'FURNACE', sub: 'Draft', x: 610, y: 30 },
    ],
    edges: [
      { from: 'pt', to: 'pic', label: 'PV' },
      { from: 'pic', to: 'sum', label: 'trim' },
      { from: 'ff-air', to: 'sum', label: 'feedforward', style: 'ff' },
      { from: 'sum', to: 'idfan', label: 'MV' },
      { from: 'idfan', to: 'furnace', label: 'flue gas out' },
      { from: 'furnace', to: 'pt', label: 'pressure', style: 'feedback' },
    ],
    sim: {
      inputLabel: 'FD fan / air flow demand (%)',
      inputMin: 30, inputMax: 100, inputDefault: 65,
      run(airDemand) {
        const sp = -5; // mmWC, slightly negative
        // Without FF the pressure would swing hard; FF keeps the error small.
        const residualErr = (airDemand - 65) * 0.04;
        const pv = sp + residualErr;
        const trim = (sp - pv) * 3;
        const idDemand = airDemand + trim;
        return {
          nodeValues: {
            'pt': `${pv.toFixed(1)} mmWC`,
            'pic': `trim ${trim >= 0 ? '+' : ''}${trim.toFixed(1)}`,
            'ff-air': `${airDemand.toFixed(0)} %`,
            'sum': `${idDemand.toFixed(0)} %`,
            'idfan': `${Math.min(100, idDemand).toFixed(0)} %`,
            'furnace': `${pv.toFixed(1)} mmWC`,
          },
          insight: Math.abs(residualErr) > 0.6
            ? `Air flow has moved, and the ID fan demand followed it almost instantly through the feedforward path — the draft PID is only trimming ${trim >= 0 ? '+' : ''}${trim.toFixed(1)}%. Without that feedforward, the pressure would swing far harder before the PID caught it.`
            : 'Balanced draft. ID and FD fans are matched, and the furnace is sitting just below atmospheric as designed.',
        };
      },
    },
    sources: [
      'Standard balanced-draft control practice (ID/FD feedforward coupling); NFPA 85 furnace pressure protection context',
    ],
  },

  // ------------------------------------------------------------------
  'coordinated-master': {
    name: 'Coordinated Master Control (CMC) \u2014 Unit Load',
    system: 'Unit',
    difficulty: 'Advanced',
    modes: [
      { id: 'coordinated', label: 'Coordinated (CMC)' },
      { id: 'boiler-follow', label: 'Boiler Follow' },
      { id: 'turbine-follow', label: 'Turbine Follow' },
    ],
    why: 'The boiler and turbine must be commanded together. This is the loop that decides whether the boiler follows the turbine, the turbine follows the boiler, or both move as one.',
    problem: 'The turbine responds in seconds; the boiler responds in minutes. Command them independently and either main steam pressure collapses (turbine opened too fast) or load response is uselessly slow (waiting for the boiler).',
    solution: 'Coordinated control. A unit master takes the load demand and splits it into a boiler demand and a turbine demand, with main steam pressure error trimming BOTH so the two stay matched. The mode selector determines which side leads.',
    elements: [
      'Boiler-follow — turbine leads on load, boiler catches up (fast response, pressure swings)',
      'Turbine-follow — boiler leads, turbine holds pressure (stable pressure, slow load)',
      'Coordinated — both move together, pressure error trims both',
    ],
    nodes: [
      { id: 'demand', type: 'demand', label: 'LOAD<br/>DEMAND', sub: 'MW target / grid AGC', x: 60, y: 130 },
      { id: 'pt-steam', type: 'sensor', label: 'PT', sub: 'Main steam pressure', x: 60, y: 250 },
      { id: 'master', type: 'controller', label: 'UNIT<br/>MASTER', sub: 'Coordinated logic', x: 240, y: 130 },
      { id: 'pic', type: 'controller', label: 'PIC', sub: 'Steam pressure PID', x: 240, y: 250 },
      { id: 'boiler-dmd', type: 'compute', label: 'BOILER<br/>DEMAND', sub: 'Firing rate', x: 435, y: 60 },
      { id: 'turb-dmd', type: 'compute', label: 'TURBINE<br/>DEMAND', sub: 'Valve position', x: 435, y: 210 },
      { id: 'firing', type: 'actuator', label: 'FIRING', sub: 'To combustion control', x: 630, y: 60 },
      { id: 'gv', type: 'actuator', label: 'GOV<br/>VALVES', sub: 'Turbine admission', x: 630, y: 210 },
    ],
    edges: [
      { from: 'demand', to: 'master', label: 'MW demand' },
      { from: 'pt-steam', to: 'pic', label: 'PV' },
      { from: 'pic', to: 'master', label: 'pressure error', style: 'feedback' },
      { from: 'master', to: 'boiler-dmd', label: '' },
      { from: 'master', to: 'turb-dmd', label: '' },
      { from: 'pic', to: 'boiler-dmd', label: 'trim', style: 'ff' },
      { from: 'pic', to: 'turb-dmd', label: 'trim', style: 'ff' },
      { from: 'boiler-dmd', to: 'firing', label: '' },
      { from: 'turb-dmd', to: 'gv', label: '' },
    ],
    sim: {
      inputLabel: 'Unit load demand (% MCR)',
      inputMin: 40, inputMax: 100, inputDefault: 75,
      run(loadDemand) {
        const spPress = 170; // bar, illustrative
        // Boiler lags the demand; pressure error is the symptom.
        const boilerActual = 75 + (loadDemand - 75) * 0.6;
        const pressErr = (boilerActual - loadDemand) * 0.8;
        const pv = spPress + pressErr;
        return {
          nodeValues: {
            'demand': `${loadDemand.toFixed(0)} %`,
            'pt-steam': `${pv.toFixed(1)} bar`,
            'master': `${loadDemand.toFixed(0)} %`,
            'pic': `err ${pressErr >= 0 ? '+' : ''}${pressErr.toFixed(1)} bar`,
            'boiler-dmd': `${(loadDemand - pressErr * 0.5).toFixed(0)} %`,
            'turb-dmd': `${(loadDemand + pressErr * 0.3).toFixed(0)} %`,
            'firing': `${(loadDemand - pressErr * 0.5).toFixed(0)} %`,
            'gv': `${(loadDemand + pressErr * 0.3).toFixed(0)} %`,
          },
          insight: Math.abs(pressErr) > 1.5
            ? `Load demand has moved faster than the boiler can follow, so main steam pressure is ${pressErr > 0 ? 'above' : 'below'} setpoint by ${Math.abs(pressErr).toFixed(1)} bar. The pressure error is trimming BOTH demands — pushing firing ${pressErr > 0 ? 'down' : 'up'} and easing the governor valves the other way to protect pressure while load catches up.`
            : 'Load and firing are matched, main steam pressure is on setpoint. This is coordinated control doing its job — boiler and turbine moving as one machine.',
        };
      },
    },
    sources: [
      'Standard coordinated boiler-turbine control practice (boiler-follow / turbine-follow / coordinated modes)',
    ],
  },

  // ------------------------------------------------------------------
  'deaerator-level': {
    name: 'Deaerator Level & Pressure Control',
    system: 'Feedwater',
    difficulty: 'Core',
    why: 'The deaerator storage tank is the ONLY suction source for the boiler feed pumps. Lose its level and you lose BFP suction — cavitation and pump damage follow within seconds.',
    problem: 'Level and pressure interact. Pegging steam holds the deaerator pressure that provides BFP suction head, but changing that pressure also changes how much the stored water flashes, which moves the level.',
    solution: 'Two loops that must be understood together: a level loop throttling condensate makeup, and a pressure loop on the pegging steam supply. Both feed the same vessel, and the pressure loop directly protects the NPSH margin the feed pumps depend on.',
    elements: [
      'Level control — condensate makeup valve',
      'Pressure control — pegging steam valve',
      'Both protect BFP suction (NPSH margin)',
    ],
    nodes: [
      { id: 'lt', type: 'sensor', label: 'LT', sub: 'Storage tank level', x: 60, y: 60 },
      { id: 'pt', type: 'sensor', label: 'PT', sub: 'Deaerator pressure', x: 60, y: 215 },
      { id: 'lic', type: 'controller', label: 'LIC', sub: 'Level PID', x: 250, y: 60 },
      { id: 'pic', type: 'controller', label: 'PIC', sub: 'Pressure PID', x: 250, y: 215 },
      { id: 'lcv', type: 'actuator', label: 'LCV', sub: 'Condensate makeup', x: 440, y: 60 },
      { id: 'pcv', type: 'actuator', label: 'PCV', sub: 'Pegging steam', x: 440, y: 215 },
      { id: 'da', type: 'process', label: 'DEAERATOR', sub: 'Storage tank', x: 630, y: 135 },
      { id: 'bfp', type: 'process', label: 'BFP', sub: 'Suction (NPSH)', x: 630, y: 280 },
    ],
    edges: [
      { from: 'lt', to: 'lic', label: 'PV' },
      { from: 'pt', to: 'pic', label: 'PV' },
      { from: 'lic', to: 'lcv', label: 'MV' },
      { from: 'pic', to: 'pcv', label: 'MV' },
      { from: 'lcv', to: 'da', label: 'makeup' },
      { from: 'pcv', to: 'da', label: 'pegging steam' },
      { from: 'da', to: 'lt', label: 'level', style: 'feedback' },
      { from: 'da', to: 'pt', label: 'pressure', style: 'feedback' },
      { from: 'da', to: 'bfp', label: 'suction head' },
    ],
    sim: {
      inputLabel: 'Feedwater draw-off (% of normal)',
      inputMin: 40, inputMax: 130, inputDefault: 100,
      run(drawOff) {
        const levelErr = -(drawOff - 100) * 0.08;
        const makeup = Math.min(100, Math.max(0, drawOff + levelErr * -2));
        const press = 5.0 - (drawOff - 100) * 0.004;
        const npsh = 12 + (press - 5.0) * 8 + levelErr * 0.5;
        return {
          nodeValues: {
            'lt': `${levelErr >= 0 ? '+' : ''}${levelErr.toFixed(0)} mm`,
            'pt': `${press.toFixed(2)} bar`,
            'lic': `err ${levelErr >= 0 ? '+' : ''}${levelErr.toFixed(1)}`,
            'pic': `err ${(5.0 - press).toFixed(2)}`,
            'lcv': `${makeup.toFixed(0)} % open`,
            'pcv': `${Math.min(100, Math.max(0, 45 + (5.0 - press) * 60)).toFixed(0)} % open`,
            'da': `${press.toFixed(2)} bar`,
            'bfp': `NPSH ${npsh.toFixed(1)} m`,
          },
          insight: npsh < 8
            ? `NPSH margin has fallen to ${npsh.toFixed(1)} m. This is the failure path that matters: low deaerator level or pressure starves the feed pumps, and BFP cavitation follows. Watch the pegging steam valve opening to defend pressure.`
            : drawOff > 110
              ? 'High feedwater draw-off. The makeup valve has opened to hold level, and pegging steam is defending the pressure that gives the feed pumps their suction head.'
              : 'Stable. Level and pressure both on setpoint, and the feed pumps have comfortable NPSH margin.',
        };
      },
    },
    sources: [
      'Standard deaerator level/pressure control practice; BFP NPSH dependency per boiler feed pump suction references',
    ],
  },

  // ------------------------------------------------------------------
  'mill-control': {
    name: 'Mill / Pulverizer Control',
    system: 'Fuel',
    difficulty: 'Advanced',
    why: 'The mill has to grind coal AND dry it AND transport it to the burners, all at once. Three interlinked controls handle it, and getting the balance wrong risks a mill fire.',
    problem: 'Coal feed sets the heat input, but primary air does two competing jobs at the same time: it carries pulverised coal to the burners AND dries it. Push the outlet temperature up for better drying and you approach the coal\u2019s ignition point inside the mill. Run it too cool and wet coal packs and blocks the pipes.',
    solution: 'Three coordinated controls: feeder speed sets coal flow, a PA flow loop holds the coal/air ratio needed for transport, and a mill outlet temperature loop blends HOT and COLD primary air to hit a drying temperature that stays safely below the ignition risk band.',
    elements: [
      'Feeder speed \u2014 sets coal flow to the mill',
      'PA flow \u2014 holds the coal/air ratio for pipe transport',
      'Hot/cold PA damper blending \u2014 controls mill outlet temperature',
    ],
    nodes: [
      { id: 'fuel-dmd', type: 'demand', label: 'FUEL<br/>DEMAND', sub: 'From boiler master', x: 55, y: 60 },
      { id: 'feeder', type: 'actuator', label: 'FEEDER', sub: 'Coal flow', x: 235, y: 60 },
      { id: 'ratio', type: 'compute', label: '\u00d7', sub: 'Coal/air ratio f(x)', x: 415, y: 60 },
      { id: 'pa-fic', type: 'controller', label: 'FIC', sub: 'PA flow PID', x: 590, y: 60 },
      { id: 'pa-damper', type: 'actuator', label: 'PA<br/>DAMPER', sub: 'Total PA flow', x: 760, y: 60 },
      { id: 'tt-out', type: 'sensor', label: 'TT', sub: 'Mill outlet temp', x: 55, y: 230 },
      { id: 'tic', type: 'controller', label: 'TIC', sub: 'Outlet temp PID', x: 235, y: 230 },
      { id: 'split', type: 'compute', label: 'SPLIT', sub: 'Hot/cold PA blend', x: 415, y: 230 },
      { id: 'hot-damper', type: 'actuator', label: 'HOT PA', sub: 'From air heater', x: 590, y: 175 },
      { id: 'cold-damper', type: 'actuator', label: 'COLD PA', sub: 'Tempering air', x: 590, y: 285 },
      { id: 'mill', type: 'process', label: 'MILL', sub: 'Grind + dry + transport', x: 760, y: 230 },
    ],
    edges: [
      { from: 'fuel-dmd', to: 'feeder', label: 'demand' },
      { from: 'feeder', to: 'ratio', label: 'coal flow' },
      { from: 'ratio', to: 'pa-fic', label: 'PA SP', style: 'cascade' },
      { from: 'pa-fic', to: 'pa-damper', label: 'MV' },
      { from: 'pa-damper', to: 'mill', label: 'primary air' },
      { from: 'feeder', to: 'mill', label: 'coal' },
      { from: 'tt-out', to: 'tic', label: 'PV' },
      { from: 'tic', to: 'split', label: 'MV' },
      { from: 'split', to: 'hot-damper', label: 'open' },
      { from: 'split', to: 'cold-damper', label: 'close', style: 'crosslimit' },
      { from: 'hot-damper', to: 'mill', label: '' },
      { from: 'cold-damper', to: 'mill', label: '' },
      { from: 'mill', to: 'tt-out', label: 'outlet temp', style: 'feedback' },
    ],
    sim: {
      inputLabel: 'Mill loading (% of rated coal flow)',
      inputMin: 30, inputMax: 100, inputDefault: 70,
      run(loading) {
        const paFlow = 25 + loading * 0.75;            // PA follows coal via ratio f(x)
        const ratio = paFlow / Math.max(1, loading);   // coal/air ratio
        const outletTemp = 78 + (loading - 70) * 0.14; // heavier load = harder to dry
        const tempSP = 80;
        const err = tempSP - outletTemp;
        const hotPct = Math.min(100, Math.max(0, 55 + err * 6));
        return {
          nodeValues: {
            'fuel-dmd': `${loading.toFixed(0)} %`,
            'feeder': `${loading.toFixed(0)} %`,
            'ratio': `${ratio.toFixed(2)} air/coal`,
            'pa-fic': `SP ${paFlow.toFixed(0)} %`,
            'pa-damper': `${Math.min(100, paFlow).toFixed(0)} %`,
            'tt-out': `${outletTemp.toFixed(1)} \u00b0C`,
            'tic': `err ${err >= 0 ? '+' : ''}${err.toFixed(1)} \u00b0C`,
            'split': `hot ${hotPct.toFixed(0)}%`,
            'hot-damper': `${hotPct.toFixed(0)} % open`,
            'cold-damper': `${(100 - hotPct).toFixed(0)} % open`,
            'mill': `${outletTemp.toFixed(1)} \u00b0C`,
          },
          insight: outletTemp > 88
            ? `Mill outlet temperature is ${outletTemp.toFixed(1)} \u00b0C and climbing toward the range where coal dust in the mill becomes a genuine fire risk. The controller is closing hot PA and opening tempering air \u2014 this is the loop that protects against a mill fire.`
            : loading < 45
              ? `Low mill loading. Note the PA flow does NOT fall proportionally \u2014 there is a minimum PA flow that must be maintained regardless of coal flow, or the pulverised coal settles out and blocks the burner pipes.`
              : `Balanced. PA flow is tracking coal flow at a ratio of ${ratio.toFixed(2)}, and the hot/cold air blend is holding outlet temperature at the drying setpoint.`,
        };
      },
    },
    sources: [
      'Standard pulverizer control practice (feeder speed, PA/coal ratio, hot/cold tempering air blending for outlet temperature)',
      'Mill outlet temperature limits relate to coal volatile content and mill fire protection \u2014 actual setpoints are coal- and OEM-specific',
    ],
  },

  // ------------------------------------------------------------------
  'turbine-bypass': {
    name: 'HP / LP Turbine Bypass Control',
    system: 'Steam',
    difficulty: 'Advanced',
    why: 'The bypass is what lets the boiler keep running when the turbine cannot take the steam \u2014 during start-up, and in the seconds after a turbine trip or load rejection.',
    problem: 'On a turbine trip the governor valves slam shut. The boiler is still firing and still making full steam flow with nowhere to go. Without somewhere for that steam to be routed, main steam pressure spikes to the safety valves within seconds and the whole unit has to be shut down.',
    solution: 'A fast pressure-control bypass. HP bypass dumps main steam to the cold reheat line, LP bypass dumps hot reheat steam straight to the condenser, and both spray-attemperate so the condenser is never hit with steam it cannot handle. On a trip the bypass opens in a fast-acting mode rather than waiting for normal PID action.',
    elements: [
      'HP bypass \u2014 main steam to cold reheat, pressure controlled',
      'LP bypass \u2014 hot reheat to condenser, with desuperheating spray',
      'Fast-open on turbine trip; modulating pressure control on start-up',
    ],
    nodes: [
      { id: 'pt-ms', type: 'sensor', label: 'PT', sub: 'Main steam pressure', x: 55, y: 60 },
      { id: 'trip', type: 'demand', label: 'TURBINE<br/>TRIP', sub: 'Fast-open signal', x: 55, y: 215 },
      { id: 'pic-hp', type: 'controller', label: 'PIC-HP', sub: 'HP bypass PID', x: 240, y: 60 },
      { id: 'hs', type: 'compute', label: 'HIGH<br/>SELECT', sub: 'PID vs fast-open', x: 425, y: 135 },
      { id: 'hp-bp', type: 'actuator', label: 'HP<br/>BYPASS', sub: 'To cold reheat', x: 610, y: 60 },
      { id: 'spray1', type: 'actuator', label: 'SPRAY', sub: 'HP BP desuperheat', x: 610, y: 175 },
      { id: 'pic-lp', type: 'controller', label: 'PIC-LP', sub: 'LP bypass PID', x: 240, y: 320 },
      { id: 'lp-bp', type: 'actuator', label: 'LP<br/>BYPASS', sub: 'To condenser', x: 610, y: 320 },
      { id: 'cond', type: 'process', label: 'CONDENSER', sub: 'Must accept the dump', x: 790, y: 320 },
    ],
    edges: [
      { from: 'pt-ms', to: 'pic-hp', label: 'PV' },
      { from: 'pic-hp', to: 'hs', label: 'MV' },
      { from: 'trip', to: 'hs', label: 'fast-open', style: 'crosslimit' },
      { from: 'hs', to: 'hp-bp', label: 'demand' },
      { from: 'hs', to: 'spray1', label: 'spray demand', style: 'ff' },
      { from: 'trip', to: 'pic-lp', label: 'fast-open', style: 'crosslimit' },
      { from: 'pic-lp', to: 'lp-bp', label: 'MV' },
      { from: 'lp-bp', to: 'cond', label: 'steam dump' },
      { from: 'hp-bp', to: 'pt-ms', label: 'pressure relief', style: 'feedback' },
    ],
    sim: {
      inputLabel: 'Turbine load accepted (% \u2014 drag to 0 to simulate a trip)',
      inputMin: 0, inputMax: 100, inputDefault: 80,
      run(turbineLoad) {
        const tripped = turbineLoad < 5;
        const bypassDemand = Math.max(0, 100 - turbineLoad);
        const pressErr = tripped ? 8 : bypassDemand * 0.05;
        const press = 170 + pressErr;
        const hpOpen = tripped ? 100 : Math.min(100, bypassDemand * 0.9);
        return {
          nodeValues: {
            'pt-ms': `${press.toFixed(1)} bar`,
            'trip': tripped ? 'TRIPPED' : 'healthy',
            'pic-hp': `err +${pressErr.toFixed(1)}`,
            'hs': `${hpOpen.toFixed(0)} %`,
            'hp-bp': `${hpOpen.toFixed(0)} % open`,
            'spray1': `${(hpOpen * 0.6).toFixed(0)} % open`,
            'pic-lp': tripped ? 'FAST OPEN' : `${(hpOpen * 0.9).toFixed(0)} %`,
            'lp-bp': `${(tripped ? 100 : hpOpen * 0.9).toFixed(0)} % open`,
            'cond': tripped ? 'full dump' : `${(hpOpen * 0.9).toFixed(0)} % dump`,
          },
          insight: tripped
            ? 'TURBINE TRIP. The fast-open signal has bypassed normal PID action through the high select \u2014 both bypasses are driven wide open immediately. The boiler keeps firing, steam routes around the turbine to the condenser, and main steam pressure is held off the safety valves. This is what lets a unit survive a turbine trip without a full boiler shutdown.'
            : turbineLoad < 50
              ? 'The turbine is taking only part of the steam flow, so the bypass is modulating to take the rest and hold main steam pressure \u2014 the normal situation during a start-up before the turbine is fully loaded.'
              : 'The turbine is accepting most of the steam. The bypass is nearly shut and simply holding main steam pressure at setpoint.',
        };
      },
    },
    sources: [
      'Standard HP/LP turbine bypass practice (pressure control, fast-open on trip, desuperheating before the condenser)',
    ],
  },

  // ------------------------------------------------------------------
  'hp-heater-level': {
    name: 'HP Heater Level Control (3-Element)',
    system: 'Feedwater Heaters',
    difficulty: 'Core',
    why: 'A flooded HP heater is one of the classic routes to destroying a turbine \u2014 water gets back up the extraction line and into the machine.',
    problem: 'Heater level must sit in a narrow band. Too low and the drain cooler section is uncovered, so live steam blows through into the drain line. Too high and the tube bundle floods, heat transfer collapses, and \u2014 far worse \u2014 water can back up the extraction line toward the turbine.',
    solution: 'Three-element control, structurally the same idea as drum level: extraction steam flow is fed FORWARD (it predicts the condensing rate), and the level controller cascades onto the drain valve. A separate high-high level trip closes the extraction non-return valve and isolates the heater entirely \u2014 the level loop is control, the trip is protection, and they are deliberately independent.',
    elements: [
      'Level \u2014 the controlled variable',
      'Extraction steam flow \u2014 fed forward (predicts condensing rate)',
      'Drain flow \u2014 the manipulated variable',
      'Independent HH trip \u2014 closes the extraction NRV (protection, not control)',
    ],
    nodes: [
      { id: 'lt', type: 'sensor', label: 'LT', sub: 'Heater shell level', x: 55, y: 60 },
      { id: 'ft-extr', type: 'sensor', label: 'FT', sub: 'Extraction steam flow', x: 55, y: 165 },
      { id: 'lic', type: 'controller', label: 'LIC', sub: 'Level PID', x: 240, y: 60 },
      { id: 'sum', type: 'compute', label: '\u03a3', sub: 'Level MV + FF', x: 425, y: 110 },
      { id: 'lcv', type: 'actuator', label: 'LCV', sub: 'Normal drain valve', x: 610, y: 110 },
      { id: 'heater', type: 'process', label: 'HP<br/>HEATER', sub: 'Shell side', x: 790, y: 60 },
      { id: 'hh-trip', type: 'compute', label: 'LEVEL HH<br/>TRIP', sub: 'Independent protection', x: 240, y: 275 },
      { id: 'nrv', type: 'actuator', label: 'EXTR<br/>NRV', sub: 'Isolates the heater', x: 610, y: 275 },
    ],
    edges: [
      { from: 'lt', to: 'lic', label: 'PV' },
      { from: 'lic', to: 'sum', label: 'MV' },
      { from: 'ft-extr', to: 'sum', label: 'feedforward', style: 'ff' },
      { from: 'sum', to: 'lcv', label: 'demand' },
      { from: 'lcv', to: 'heater', label: 'drain out' },
      { from: 'heater', to: 'lt', label: 'level', style: 'feedback' },
      { from: 'lt', to: 'hh-trip', label: 'HH', style: 'crosslimit' },
      { from: 'hh-trip', to: 'nrv', label: 'close', style: 'crosslimit' },
      { from: 'nrv', to: 'heater', label: 'isolate' },
    ],
    sim: {
      inputLabel: 'Extraction steam flow (%) — push above ~110% to trip the heater',
      inputMin: 20, inputMax: 140, inputDefault: 70,
      run(level) {
        const hhTrip = 150;
        const tripped = level >= hhTrip;
        const drainOpen = Math.min(100, Math.max(0, 45 + level * 0.3));
        return {
          nodeValues: {
            'lt': `${level >= 0 ? '+' : ''}${level.toFixed(0)} mm`,
            'ft-extr': `${(70 + level * 0.05).toFixed(0)} %`,
            'lic': `err ${(-level).toFixed(0)} mm`,
            'sum': `${drainOpen.toFixed(0)} %`,
            'lcv': `${drainOpen.toFixed(0)} % open`,
            'heater': `${level >= 0 ? '+' : ''}${level.toFixed(0)} mm`,
            'hh-trip': tripped ? 'TRIPPED' : `armed (${hhTrip} mm)`,
            'nrv': tripped ? 'CLOSED' : 'open',
          },
          insight: tripped
            ? `Level has reached the HIGH-HIGH trip at ${hhTrip} mm. The extraction non-return valve has closed and the heater is isolated. Notice this happened through the INDEPENDENT protection path \u2014 not through the level controller. That separation is deliberate: if the control loop itself is what failed, protection must not depend on it.`
            : level > 80
              ? 'Level is high and the drain valve is driving open. If the level keeps rising, the independent HH trip will isolate the heater before water can back up the extraction line toward the turbine.'
              : level < -100
                ? 'Level is low. Push it much lower and the drain cooler section uncovers, letting live steam blow through into the drain line \u2014 which erodes the drain valve and the downstream piping.'
                : 'Level on setpoint. The drain valve is modulating with extraction flow fed forward, so the loop anticipates changes in condensing rate rather than chasing them.',
        };
      },
    },
    sources: [
      'Standard HP/LP feedwater heater level control practice (3-element with extraction flow feedforward)',
      'Extraction non-return valve closure on high heater level \u2014 turbine water induction protection (consistent with the extraction NRV entry in this app\u2019s trip registry)',
    ],
  },

  // ------------------------------------------------------------------
  'condenser-hotwell': {
    name: 'Condenser Hotwell Level Control',
    system: 'Condensate',
    difficulty: 'Core',
    why: 'The hotwell is the cycle\u2019s water buffer. It absorbs every mismatch between what the turbine exhausts and what the feedwater system draws \u2014 and it feeds the condensate pumps.',
    problem: 'Two failure modes in opposite directions. Level too low and the condensate pumps lose suction and cavitate. Level too high and the tube bundle floods, condenser performance collapses, and backpressure rises \u2014 costing turbine output immediately.',
    solution: 'A level controller that splits its output across two ranges: on falling level it opens makeup from the storage tank, and on rising level it opens the dump/reject valve back to storage. A single controller drives both, with a deliberate deadband between them so the two valves never fight each other.',
    elements: [
      'Level PID with split-range output',
      'Makeup valve \u2014 opens on falling level',
      'Reject/dump valve \u2014 opens on rising level',
      'Deadband between them so they never fight',
    ],
    nodes: [
      { id: 'lt', type: 'sensor', label: 'LT', sub: 'Hotwell level', x: 55, y: 130 },
      { id: 'lic', type: 'controller', label: 'LIC', sub: 'Level PID', x: 250, y: 130 },
      { id: 'split', type: 'compute', label: 'SPLIT<br/>RANGE', sub: 'With deadband', x: 445, y: 130 },
      { id: 'makeup', type: 'actuator', label: 'MAKEUP', sub: 'From storage tank', x: 640, y: 55 },
      { id: 'reject', type: 'actuator', label: 'REJECT', sub: 'Dump to storage', x: 640, y: 210 },
      { id: 'hotwell', type: 'process', label: 'HOTWELL', sub: 'Cycle water buffer', x: 830, y: 130 },
      { id: 'cep', type: 'process', label: 'CEP', sub: 'Suction (NPSH)', x: 830, y: 265 },
    ],
    edges: [
      { from: 'lt', to: 'lic', label: 'PV' },
      { from: 'lic', to: 'split', label: 'MV' },
      { from: 'split', to: 'makeup', label: '0\u201345 %' },
      { from: 'split', to: 'reject', label: '55\u2013100 %' },
      { from: 'makeup', to: 'hotwell', label: 'in' },
      { from: 'reject', to: 'hotwell', label: 'out' },
      { from: 'hotwell', to: 'lt', label: 'level', style: 'feedback' },
      { from: 'hotwell', to: 'cep', label: 'suction head' },
    ],
    sim: {
      inputLabel: 'Cooling water / condensate flow imbalance',
      inputMin: -80, inputMax: 80, inputDefault: 0,
      run(level) {
        const mv = 50 - level * 0.14;              // PID output, 50% = deadband centre
        const makeup = mv < 45 ? Math.min(100, (45 - mv) * 2.2) : 0;
        const reject = mv > 55 ? Math.min(100, (mv - 55) * 2.2) : 0;
        const npsh = 9 + level * 0.012;
        return {
          nodeValues: {
            'lt': `${level >= 0 ? '+' : ''}${level.toFixed(0)} mm`,
            'lic': `MV ${mv.toFixed(0)} %`,
            'split': makeup > 0 ? 'makeup band' : reject > 0 ? 'reject band' : 'deadband',
            'makeup': `${makeup.toFixed(0)} % open`,
            'reject': `${reject.toFixed(0)} % open`,
            'hotwell': `${level >= 0 ? '+' : ''}${level.toFixed(0)} mm`,
            'cep': `NPSH ${npsh.toFixed(1)} m`,
          },
          insight: npsh < 6
            ? `Hotwell level is low and CEP NPSH margin has fallen to ${npsh.toFixed(1)} m. Makeup is wide open, but if level keeps dropping the condensate pumps will cavitate \u2014 this is the failure path that matters on the low side.`
            : level > 150
              ? 'Level is high and the reject valve is dumping back to storage. Left unchecked, a flooded tube bundle degrades the condenser and drives turbine backpressure up, which costs output straight away.'
              : makeup === 0 && reject === 0
                ? 'Level is inside the deadband, so BOTH valves are shut. That gap is deliberate \u2014 without it, makeup and reject would sit partly open at the same time, endlessly cycling water back and forth.'
                : 'Level is off setpoint and the split-range output is correcting it with one valve only \u2014 never both at once.',
        };
      },
    },
    sources: [
      'Standard condenser hotwell level control practice (split-range makeup/reject with deadband)',
      'CEP NPSH dependency on hotwell level \u2014 consistent with the hotwell low-low trip entry in this app\u2019s registry',
    ],
  },

  // ------------------------------------------------------------------
  'avr-excitation': {
    name: 'AVR / Excitation Control (Generator Voltage)',
    system: 'Generator',
    difficulty: 'Advanced',
    why: 'The only loop on this list that controls the ELECTRICAL machine. It sets generator terminal voltage off-line, and reactive power once synchronised \u2014 and it carries the limiters that keep the machine inside its capability curve.',
    problem: 'The same controller has to do two quite different jobs. Before synchronising, it holds terminal voltage so the machine can be matched to the grid. After the breaker closes, the grid fixes the voltage \u2014 so the same control action now pushes reactive power (MVAr) instead. Push too far either way and you damage the machine.',
    solution: 'A voltage PID driving field current, wrapped in a set of limiters that override it: OEL caps field current (rotor thermal limit), UEL stops under-excitation (stator end-core heating and loss of synchronism risk), and a V/Hz limiter protects against over-fluxing at low speed. The limiters take precedence over the AVR \u2014 they are not suggestions.',
    elements: [
      'AVR voltage PID \u2014 the main loop',
      'OEL (over-excitation limiter) \u2014 rotor thermal protection',
      'UEL (under-excitation limiter) \u2014 stator end-core and stability protection',
      'V/Hz limiter \u2014 over-fluxing protection at low speed',
      'PSS \u2014 damps power oscillations on the grid',
    ],
    nodes: [
      { id: 'vt', type: 'sensor', label: 'VT', sub: 'Terminal voltage', x: 55, y: 70 },
      { id: 'sp', type: 'demand', label: 'VOLTAGE<br/>SETPOINT', sub: 'Operator / AVR SP', x: 55, y: 195 },
      { id: 'avr', type: 'controller', label: 'AVR', sub: 'Voltage PID', x: 245, y: 130 },
      { id: 'limiters', type: 'compute', label: 'LIMITERS', sub: 'OEL / UEL / V-Hz', x: 435, y: 130 },
      { id: 'pss', type: 'controller', label: 'PSS', sub: 'Power system stabiliser', x: 435, y: 265 },
      { id: 'exciter', type: 'actuator', label: 'EXCITER', sub: 'Field current', x: 625, y: 130 },
      { id: 'gen', type: 'process', label: 'GENERATOR', sub: 'Field \u2192 V and MVAr', x: 815, y: 130 },
      { id: 'ct', type: 'sensor', label: 'CT', sub: 'Stator / field current', x: 625, y: 265 },
    ],
    edges: [
      { from: 'vt', to: 'avr', label: 'PV' },
      { from: 'sp', to: 'avr', label: 'SP' },
      { from: 'avr', to: 'limiters', label: 'MV' },
      { from: 'pss', to: 'limiters', label: 'damping', style: 'ff' },
      { from: 'limiters', to: 'exciter', label: 'limited MV', style: 'crosslimit' },
      { from: 'exciter', to: 'gen', label: 'field current' },
      { from: 'gen', to: 'vt', label: 'terminal V', style: 'feedback' },
      { from: 'ct', to: 'limiters', label: 'current feedback', style: 'feedback' },
      { from: 'gen', to: 'ct', label: '' },
    ],
    sim: {
      inputLabel: 'Excitation / reactive load (% of rated field current)',
      inputMin: 40, inputMax: 130, inputDefault: 85,
      run(field) {
        const oel = 110, uel = 55;
        const oelActive = field >= oel;
        const uelActive = field <= uel;
        const limited = Math.min(oel, Math.max(uel, field));
        const mvar = (limited - 80) * 4.5;
        const terminalV = 100 + (limited - 85) * 0.12;
        return {
          nodeValues: {
            'vt': `${terminalV.toFixed(1)} %`,
            'sp': `100.0 %`,
            'avr': `err ${(100 - terminalV).toFixed(2)} %`,
            'limiters': oelActive ? 'OEL ACTIVE' : uelActive ? 'UEL ACTIVE' : 'not limiting',
            'pss': 'damping',
            'exciter': `${limited.toFixed(0)} % field`,
            'gen': `${mvar >= 0 ? '+' : ''}${mvar.toFixed(0)} MVAr`,
            'ct': `${limited.toFixed(0)} %`,
          },
          insight: oelActive
            ? `The OVER-EXCITATION LIMITER has taken control and clamped field current at ${oel}%. The AVR is still asking for more, but the limiter overrides it \u2014 sustained over-excitation overheats the rotor winding. Note this is a LIMITER (it holds the machine at the boundary), not a trip; the loss-of-field and over-excitation protections sit behind it as separate trips.`
            : uelActive
              ? `The UNDER-EXCITATION LIMITER is active at ${uel}%. Running too far under-excited heats the stator end-core and moves the machine toward the stability limit \u2014 the region where loss of synchronism becomes a real risk.`
              : mvar > 60
                ? `Over-excited: the machine is exporting ${mvar.toFixed(0)} MVAr to the grid (supporting system voltage). Field current has headroom before the OEL.`
                : mvar < -40
                  ? `Under-excited: the machine is absorbing ${Math.abs(mvar).toFixed(0)} MVAr. Watch the margin to the UEL \u2014 this is the direction that leads toward the stability limit.`
                  : 'Normal excitation. Terminal voltage on setpoint, reactive load modest, and no limiter is active.',
        };
      },
    },
    sources: [
      'Standard AVR/excitation control architecture (voltage PID with OEL, UEL and V/Hz limiters, plus PSS)',
      'Limiter functions relate to the generator capability curve; loss-of-excitation (40) and over-excitation protections are separate trips \u2014 see this app\u2019s trip registry',
    ],
  },

  // ------------------------------------------------------------------
  'firewater-ratio': {
    name: 'Once-Through Boiler Fire/Water Ratio Control',
    system: 'Boiler / USC-specific',
    difficulty: 'Advanced',
    why: 'A drum boiler has a large water reservoir that buffers any mismatch between firing and feedwater. An ultra-supercritical once-through (Benson-type) boiler has no drum at all \u2014 feedwater passes through the tubes exactly once, so there is no energy storage margin to hide an imbalance. The fire/water ratio is how these units hold steam temperature instead.',
    problem: 'In a drum boiler, steam temperature is trimmed mainly by spray attemperation while the drum quietly absorbs any firing/feedwater mismatch. A once-through boiler cannot do that: if feedwater flow and firing rate drift out of the correct ratio, the mismatch shows up almost immediately as a steam temperature swing, because every kilogram of water that enters must pick up exactly enough heat to leave as steam at the right temperature \u2014 there is nothing in between to average it out.',
    solution: 'Firing rate and feedwater flow are commanded together, in parallel, straight from load demand \u2014 not one cascaded from the other. Their RATIO becomes the primary handle for steam temperature: too hot, trim firing back (or add feedwater); too cool, do the opposite. Spray still exists, but only as a fast, small trim on top of a ratio that is already close to correct. Feedwater temperature (from the HP heaters) is fed forward into the ratio too, since colder feedwater consumes more of the available heat just reaching saturation, leaving less for the superheater.',
    elements: [
      'Firing rate demand \u2014 parallel feedforward from load, not cascaded from feedwater',
      'Feedwater flow demand \u2014 parallel feedforward from load',
      'Fire/water ratio \u2014 the primary steam temperature handle (unique to once-through boilers)',
      'Feedwater temperature feedforward \u2014 compensates for colder/hotter feedwater',
      'Spray \u2014 present only as a fast trim, not the primary mechanism',
    ],
    nodes: [
      { id: 'load', type: 'demand', label: 'LOAD<br/>DEMAND', sub: 'Unit load demand', x: 55, y: 140 },
      { id: 'firing-ff', type: 'compute', label: 'FIRING<br/>DEMAND', sub: 'Feedforward from load', x: 250, y: 60 },
      { id: 'fw-ff', type: 'compute', label: 'FEEDWATER<br/>DEMAND', sub: 'Feedforward from load', x: 250, y: 230 },
      { id: 'fwtemp', type: 'sensor', label: 'TT', sub: 'Feedwater temperature', x: 250, y: 340 },
      { id: 'ratio', type: 'compute', label: '\u00f7', sub: 'Fire/water ratio', x: 440, y: 140 },
      { id: 'tic', type: 'controller', label: 'TIC', sub: 'Steam temp PID (trims ratio)', x: 440, y: 260 },
      { id: 'tt-out', type: 'sensor', label: 'TT', sub: 'Final steam temperature', x: 630, y: 260 },
      { id: 'spray', type: 'actuator', label: 'SPRAY', sub: 'Fast trim only', x: 630, y: 60 },
      { id: 'boiler', type: 'process', label: 'ONCE-<br/>THROUGH<br/>TUBES', sub: 'No drum \u2014 no buffer', x: 820, y: 160 },
    ],
    edges: [
      { from: 'load', to: 'firing-ff', label: '' },
      { from: 'load', to: 'fw-ff', label: '' },
      { from: 'firing-ff', to: 'ratio', label: '' },
      { from: 'fw-ff', to: 'ratio', label: '' },
      { from: 'fwtemp', to: 'ratio', label: 'feedforward', style: 'ff' },
      { from: 'tic', to: 'firing-ff', label: 'trims ratio', style: 'cascade' },
      { from: 'tt-out', to: 'tic', label: 'PV', style: 'feedback' },
      { from: 'ratio', to: 'spray', label: 'residual trim', style: 'ff' },
      { from: 'firing-ff', to: 'boiler', label: 'firing' },
      { from: 'fw-ff', to: 'boiler', label: 'feedwater' },
      { from: 'spray', to: 'boiler', label: '' },
      { from: 'boiler', to: 'tt-out', label: 'steam out' },
    ],
    sim: {
      inputLabel: 'Feedwater temperature deviation (\u00b0C from normal)',
      inputMin: -40, inputMax: 20, inputDefault: 0,
      run(fwTempDev) {
        const targetRatio = 1.0;
        // Colder feedwater consumes more heat just reaching saturation,
        // so the ratio needed to hold temperature rises as fwTempDev falls.
        const ratioNeeded = targetRatio - fwTempDev * 0.006;
        const firingTrim = (ratioNeeded - targetRatio) * 100;
        const tempErr = -fwTempDev * 1.1;
        const sprayPct = Math.min(100, Math.max(0, 20 - fwTempDev * 1.5));
        const outletTemp = 600 + tempErr - sprayPct * 0.15;
        return {
          nodeValues: {
            'load': '75 %',
            'firing-ff': `${(75 + firingTrim).toFixed(1)} %`,
            'fw-ff': '75.0 %',
            'fwtemp': `${fwTempDev >= 0 ? '+' : ''}${fwTempDev.toFixed(0)} \u00b0C`,
            'ratio': `${ratioNeeded.toFixed(3)}`,
            'tic': `err ${tempErr >= 0 ? '+' : ''}${tempErr.toFixed(1)} \u00b0C`,
            'tt-out': `${outletTemp.toFixed(0)} \u00b0C`,
            'spray': `${sprayPct.toFixed(0)} % open`,
            'boiler': `${outletTemp.toFixed(0)} \u00b0C`,
          },
          insight: Math.abs(fwTempDev) > 10
            ? `Feedwater is ${Math.abs(fwTempDev).toFixed(0)} \u00b0C ${fwTempDev < 0 ? 'colder' : 'hotter'} than normal (an HP heater out of service is the classic cause). The fire/water ratio has moved to ${ratioNeeded.toFixed(3)} to compensate \u2014 in a drum boiler this would barely register; in a once-through boiler it shows up in steam temperature almost immediately, because there is no drum inventory to absorb it.`
            : 'Feedwater temperature near normal. The fire/water ratio is holding close to its design value, with spray doing only a small trim on top \u2014 not the primary job.',
        };
      },
    },
    sources: [
      'US Patent 4,068,475 \u2014 Flow control for once-through boiler having integral separators (pressure/water-fuel ratio relationship during startup and operation)',
      'PowerMag \u2014 Design Features of Advanced Ultrasupercritical Plants, Part III: "steam temperature is controlled by the adjustment of the ratio of firing rate to feedwater flow"',
      'Industrial Monitor Direct \u2014 Once-Through Boiler Low Feedwater Temperature Steam Temperature Effect (FR/FW ratio compensation for feedwater temperature)',
      'Control Engineering \u2014 "Supercritical Control": once-through boilers have no drum energy reserve, so firing and feedwater must be matched continuously',
    ],
  },

  // ------------------------------------------------------------------
  'sliding-pressure': {
    name: 'Sliding Pressure / Governor Valve Position',
    system: 'Turbine / USC-specific',
    difficulty: 'Advanced',
    why: 'Every other pressure loop on this list holds a FIXED setpoint. Ultra-supercritical once-through units very often do the opposite through the middle of their load range: they let boiler pressure slide with load and hold the turbine governor valves wide open, specifically to avoid throttling losses.',
    problem: 'Throttling steam through partly-closed governor valves destroys the availability of that steam \u2014 pressure is dropped at the valve for no thermodynamic benefit. At full valve opening there is no throttling loss at all, but a fixed high pressure setpoint forces the valves to throttle at every load below 100%.',
    solution: 'Below roughly 70% load, pressure is held at a fixed minimum. Between about 70% and 90%, pressure SLIDES down roughly in proportion to load while the governor valves stay wide open \u2014 load is controlled by how much steam the boiler makes, not by how far the valves are throttled. Above about 90%, pressure is held fixed again as a deliberate reserve: a small throttling margin that lets the unit respond instantly to a load demand by simply opening the valves further, without waiting for the boiler to react.',
    elements: [
      'Load-to-pressure schedule \u2014 fixed / sliding / fixed, not a single setpoint',
      'Below ~70% load: fixed minimum pressure',
      '~70\u201390% load: pressure slides with load, valves wide open',
      'Above ~90% load: fixed pressure again, valves throttle to hold a fast-response reserve',
    ],
    nodes: [
      { id: 'load', type: 'demand', label: 'LOAD<br/>DEMAND', sub: '% MCR', x: 55, y: 140 },
      { id: 'schedule', type: 'compute', label: 'f(x)', sub: 'Load \u2192 pressure schedule', x: 250, y: 140 },
      { id: 'pic', type: 'controller', label: 'PIC', sub: 'Boiler pressure PID', x: 440, y: 60 },
      { id: 'pt', type: 'sensor', label: 'PT', sub: 'Main steam pressure', x: 440, y: 200 },
      { id: 'firing', type: 'actuator', label: 'FIRING', sub: 'To combustion control', x: 630, y: 60 },
      { id: 'gv', type: 'actuator', label: 'GOV<br/>VALVES', sub: 'Position (open = less throttling)', x: 630, y: 260 },
      { id: 'turbine', type: 'process', label: 'TURBINE', sub: 'Admission', x: 820, y: 200 },
    ],
    edges: [
      { from: 'load', to: 'schedule', label: '' },
      { from: 'schedule', to: 'pic', label: 'sliding SP', style: 'cascade' },
      { from: 'pt', to: 'pic', label: 'PV', style: 'feedback' },
      { from: 'pic', to: 'firing', label: 'MV' },
      { from: 'load', to: 'gv', label: 'position demand', style: 'ff' },
      { from: 'gv', to: 'turbine', label: '' },
      { from: 'firing', to: 'pt', label: 'steam production' },
      { from: 'turbine', to: 'pt', label: 'steam takeoff', style: 'feedback' },
    ],
    sim: {
      inputLabel: 'Unit load demand (% MCR)',
      inputMin: 40, inputMax: 100, inputDefault: 80,
      run(load) {
        const pMin = 120, pRated = 170;
        let pSP, regime;
        if (load <= 70) { pSP = pMin; regime = 'FIXED (below sliding band)'; }
        else if (load >= 90) { pSP = pRated; regime = 'FIXED (reserve band)'; }
        else { pSP = pMin + (pRated - pMin) * ((load - 70) / 20); regime = 'SLIDING'; }

        let valvePos;
        if (load <= 70) valvePos = 55 + (load - 40) * 0.5;
        else if (load >= 90) valvePos = 100 - (load - 90) * 3;
        else valvePos = 95;

        const throttleLossPct = Math.max(0, (100 - valvePos) * 0.18);

        return {
          nodeValues: {
            'load': `${load.toFixed(0)} %`,
            'schedule': `${pSP.toFixed(0)} bar`,
            'pic': `SP ${pSP.toFixed(0)} bar`,
            'pt': `${pSP.toFixed(1)} bar`,
            'firing': `${load.toFixed(0)} %`,
            'gv': `${valvePos.toFixed(0)} % open`,
            'turbine': `${load.toFixed(0)} % load`,
          },
          strategy: regime,
          insight: regime === 'SLIDING'
            ? `Sliding pressure band. Governor valves are held almost wide open (${valvePos.toFixed(0)}%) and pressure itself is doing the work of matching steam supply to turbine demand \u2014 throttling loss is only about ${throttleLossPct.toFixed(1)}%, versus what a fixed-pressure unit would waste at this same load.`
            : load < 70
              ? `Below the sliding band. Pressure is held at its fixed minimum (${pMin} bar), and the valves modulate more to control load at this end of the range.`
              : `Above the sliding band \u2014 pressure is deliberately held fixed at ${pRated} bar again. This is NOT wasted throttling: it is a reserve. If load demand jumps right now, the valves can simply open further and deliver more steam instantly, without waiting for the boiler to raise pressure first.`,
        };
      },
    },
    sources: [
      'ScienceDirect Topics \u2014 Sliding Pressure: sliding set point typically effective between ~70% and 90% load, fixed below and fixed above as a reserve for once-through boilers',
      'PowerMag \u2014 Constant and sliding-pressure options for new supercritical plants (throttling loss vs load-response trade-off)',
      'PowerMag \u2014 Design Features of Advanced Ultrasupercritical Plants, Part III (modified sliding pressure keeps a throttling reserve near full load)',
    ],
  },

  'condenser-vacuum': {
    name: 'Condenser Vacuum (Backpressure) Control',
    system: 'Condensate',
    difficulty: 'Advanced',
    why: 'Every degree of condenser backpressure costs turbine output directly \u2014 unlike almost every other loop in the plant, this one is a straight line to lost MW and lost efficiency, not just a stability concern.',
    problem: 'Two very different things raise condenser pressure, and only one of them is fixable by this loop. Warmer cooling water raises the achievable vacuum floor \u2014 pure thermodynamics, no valve can undo it. Air in-leakage (worn seals, packing, valve glands) blankets the tube bundle with non-condensable gas on top of that floor \u2014 and THAT part the ejectors can and must remove.',
    solution: 'A pressure controller trims air ejector or vacuum pump capacity to keep the non-condensable gas load from ever accumulating. It cannot lower the cooling-water-set floor \u2014 no controller can \u2014 but it keeps the plant sitting AT that floor instead of drifting above it.',
    elements: [
      'PIC trims ejector/vacuum pump capacity, not the water side',
      'Base pressure set by cooling water temperature \u2014 outside this loop\u2019s authority',
      'Gas blanketing is the part the ejector actually controls',
    ],
    nodes: [
      { id: 'cwtemp', type: 'demand', label: 'CW INLET<br/>TEMP', sub: 'Cooling water', x: 55, y: 260 },
      { id: 'condenser', type: 'process', label: 'CONDENSER', sub: 'Steam-side vacuum', x: 630, y: 190 },
      { id: 'pt', type: 'sensor', label: 'PT', sub: 'Condenser pressure', x: 55, y: 90 },
      { id: 'pic', type: 'controller', label: 'PIC', sub: 'Vacuum PID', x: 250, y: 90 },
      { id: 'ejector', type: 'actuator', label: 'EJECTOR', sub: 'Air ejector / vac. pump', x: 445, y: 90 },
    ],
    edges: [
      { from: 'cwtemp', to: 'condenser', label: 'sets pressure floor' },
      { from: 'condenser', to: 'pt', label: 'PV', style: 'feedback' },
      { from: 'pt', to: 'pic', label: 'PV' },
      { from: 'pic', to: 'ejector', label: 'MV' },
      { from: 'ejector', to: 'condenser', label: 'removes gas' },
    ],
    sim: {
      inputLabel: 'Cooling water inlet temperature (\u00b0C)',
      inputMin: 15, inputMax: 35, inputDefault: 25,
      run(cwTempC) {
        return { nodeValues: { 'cwtemp': `${cwTempC.toFixed(0)} \u00b0C` }, insight: '' };
      },
    },
    sources: [
      'Standard surface condenser design practice \u2014 backpressure set by CW temperature and terminal temperature difference (TTD), non-condensable gas removal by air ejectors or liquid-ring vacuum pumps',
      'IAPWS-IF97 \u2014 saturation pressure/temperature relationship used directly for the achievable-vacuum floor in this simulation',
    ],
  },

};

/** Node type -> display colour token and shape hint, used by the renderer. */
/**
 * DYNAMIC SIMULATION MODELS
 * =========================
 * Each factory returns a stateful simulator: call step(dt, input) at a
 * fixed timestep and it advances the real process and controller dynamics,
 * returning live node values plus a trended primary variable.
 *
 * These are first-order-plus-dead-time process approximations with real PI
 * controllers, anti-windup and actuator rate limits. They reproduce the
 * behaviour that actually matters on each loop: which way the level moves
 * first, whether air genuinely leads fuel, and whether the cascade catches
 * a disturbance before the outlet ever sees it.
 *
 * TIME CONSTANTS are typical published magnitudes, not values from any one
 * unit. The SHAPE of the response is the accurate part; treat the exact
 * seconds as illustrative.
 */

/**
 * Packs a PID's live state for display: what it compares, what it outputs,
 * and how far through its output range that sits. The UI draws this as a
 * labelled SP / PV / OUT block with a bar, which is far easier to read than
 * a bare "trim -0.6".
 */
function ctrl(pid, { unit = '', outUnit = '%', role = '' } = {}) {
  return {
    sp: pid.sp, pv: pid.pv, out: pid.out, unit, outUnit, role,
    outMin: pid.outMin, outMax: pid.outMax,
    outPct: ((pid.out - pid.outMin) / (pid.outMax - pid.outMin)) * 100,
    saturated: pid.saturated,
  };
}

/** Packs a final element position for display as a fill bar. */
function elem(value, { unit = '%', min = 0, max = 100, label = '' } = {}) {
  return { value, unit, min, max, label, pct: ((value - min) / (max - min)) * 100 };
}

export const LOOP_DYNAMICS = {

  // Drum level: an INTEGRATING process with inverse response (shrink/swell).
  'drum-level-3e': () => {
    const swell = new InverseResponse({ fastGain: 2.2, fastTau: 6, slowGain: -2.2, slowTau: 45 });
    const fwValve = new Lag(3, 60);
    const fwFlow = new Lag(2, 60);
    const levelInt = new Integrator(0.55, 0, -400, 400);
    const lic = new PID({ kp: 0.9, ki: 0.020, outMin: -40, outMax: 40, initialOutput: 0 });
    const fic = new PID({ kp: 1.1, ki: 0.55, outMin: 0, outMax: 100, initialOutput: 60 });
    let steamPrev = 60;
    return {
      trendLabel: 'Drum level (mm)', setpoint: 0,
      step(dt, steamDemand) {
        const dSteam = (steamDemand - steamPrev) / dt;
        steamPrev = steamDemand;
        // Shrink/swell is driven by the RATE of steam demand change.
        const swellMm = swell.step(dSteam, dt);
        const level = levelInt.y + swellMm;
        const trim = lic.step(0, level, dt);
        const fwSP = clamp(steamDemand + trim, 0, 100);
        const fwCmd = fic.step(fwSP, fwFlow.y, dt);
        const valve = fwValve.step(fwCmd, dt);
        const fw = fwFlow.step(valve, dt);
        levelInt.step((fw - steamDemand) / 100, dt);
        return {
          trend: level,
          nodeValues: {
            'lt': `${level >= 0 ? '+' : ''}${level.toFixed(0)} mm`,
            'ft-steam': `${steamDemand.toFixed(0)} %`,
            'ft-fw': `${fw.toFixed(1)} %`,
            'lic': `trim ${trim >= 0 ? '+' : ''}${trim.toFixed(1)}${lic.saturated ? ' SAT' : ''}`,
            'sum': `${fwSP.toFixed(1)} %`,
            'fic': `err ${(fwSP - fw).toFixed(2)}`,
            'fcv': `${valve.toFixed(1)} % open`,
            'drum': `${level >= 0 ? '+' : ''}${level.toFixed(0)} mm`,
          },
          strategy: 'CASCADE + FEEDFORWARD',
          controllers: {
            'lic': ctrl(lic, { unit: 'mm', outUnit: '% trim', role: 'MASTER \u2014 holds level' }),
            'fic': ctrl(fic, { unit: '%', outUnit: '% valve', role: 'SLAVE \u2014 holds feedwater flow' }),
          },
          elements: { 'fcv': elem(valve, { label: 'Feedwater valve' }) },
          chain: [
            { step: 'Steam flow (feedforward)', value: steamDemand.toFixed(1) + ' %',
              why: 'The bulk demand. Feeding this FORWARD means feedwater tracks steam immediately instead of waiting for a level error.' },
            { step: 'Level master trim', value: (trim >= 0 ? '+' : '') + trim.toFixed(2) + ' %',
              why: 'The master only corrects the small leftover error \u2014 it does not set flow by itself.' },
            { step: 'Sum \u2192 slave setpoint', value: fwSP.toFixed(1) + ' %',
              why: 'feedforward ' + steamDemand.toFixed(1) + ' + trim ' + (trim >= 0 ? '+' : '') + trim.toFixed(2) + ' = ' + fwSP.toFixed(1) + '. This is the CASCADE handover: the master output becomes the slave SETPOINT.' },
            { step: 'Slave flow controller', value: fwSP.toFixed(1) + ' \u2192 ' + fw.toFixed(1) + ' %',
              why: 'The slave drives the valve until measured feedwater flow equals that setpoint.' },
            { step: 'Valve position', value: valve.toFixed(1) + ' % open', why: 'Final element.' },
          ],
          insight: Math.abs(swellMm) > 1.2
            ? `SHRINK/SWELL ACTIVE \u2014 the level is reading ${swellMm > 0 ? 'HIGH (swell)' : 'LOW (shrink)'} by about ${Math.abs(swellMm).toFixed(1)} mm purely from the density change. The drum mass has not actually moved that way. A single-element controller would react to this false signal and drive feedwater the WRONG way; watch feedwater instead follow steam flow through the feedforward path.`
            : Math.abs(level) > 12
              ? `Level ${level > 0 ? 'above' : 'below'} setpoint by ${Math.abs(level).toFixed(0)} mm; the master is trimming feedwater. Level is an INTEGRATING process \u2014 it will not settle on its own, only the controller brings it back.`
              : 'Level stable at setpoint. Feedwater is matching steam flow, with the master PI trimming only small residual errors.',
        };
      },
    };
  },

  // Combustion: cross-limiting with genuinely different fuel and air dynamics.
  'combustion-cross-limit': () => {
    // Fuel is SLOW (mill grinding + transport); air is FAST (damper/fan).
    // That asymmetry is precisely why cross-limiting is needed.
    const fuelLag = new Lag(45, 70);
    const airLag = new Lag(5, 70);
    const fuelRate = new RateLimit(3, 70);
    const airRate = new RateLimit(25, 70);
    const aic = new PID({ kp: 3.0, ki: 1.4, outMin: 0, outMax: 100, initialOutput: 70 });
    const fic = new PID({ kp: 1.0, ki: 0.22, outMin: 0, outMax: 100, initialOutput: 70 });
    const o2Lag = new Lag(20, 3.2);
    return {
      trendLabel: 'Air minus fuel (%)', setpoint: 0,
      step(dt, demand) {
        const airFlow = airLag.y, fuelFlow = fuelLag.y;
        // HIGH select on air, plus the excess-air margin real schemes carry
        // so air flow stays strictly ABOVE fuel flow rather than merely equal.
        const airDemand = Math.max(demand, fuelFlow) * 1.04;
        const fuelDemand = Math.min(demand, airFlow);   // LOW select on fuel
        const airCmd = airRate.step(aic.step(airDemand, airFlow, dt), dt);
        const fuelCmd = fuelRate.step(fic.step(fuelDemand, fuelFlow, dt), dt);
        const air = airLag.step(airCmd, dt);
        const fuel = fuelLag.step(fuelCmd, dt);
        const ratio = fuel > 0.1 ? air / fuel : 2;
        const o2 = o2Lag.step(clamp((ratio - 1) * 21 + 1.2, 0.2, 12), dt);
        return {
          trend: air - fuel,
          nodeValues: {
            'master': `${demand.toFixed(0)} %`,
            'hs': `${airDemand.toFixed(1)} %`,
            'ls': `${fuelDemand.toFixed(1)} %`,
            'ratio': `${(airDemand * 1.15).toFixed(1)} %`,
            'o2': `${o2.toFixed(2)} % O\u2082`,
            'aic': `SP ${airDemand.toFixed(1)}`,
            'fic': `SP ${fuelDemand.toFixed(1)}`,
            'damper': `${airCmd.toFixed(1)} %`,
            'feeder': `${fuelCmd.toFixed(1)} %`,
            'ft-air': `${air.toFixed(1)} %`,
            'ft-fuel': `${fuel.toFixed(1)} %`,
          },
          strategy: 'RATIO + CROSS-LIMIT SELECT',
          controllers: {
            'aic': ctrl(aic, { unit: '%', outUnit: '% damper', role: 'Air flow' }),
            'fic': ctrl(fic, { unit: '%', outUnit: '% feeder', role: 'Fuel flow' }),
          },
          elements: { 'damper': elem(airCmd, { label: 'FD damper' }), 'feeder': elem(fuelCmd, { label: 'Feeder' }) },
          chain: [
            { step: 'Boiler master demand', value: demand.toFixed(1) + ' %', why: 'What the unit is asking for.' },
            { step: 'HIGH select \u2192 air SP', value: airDemand.toFixed(1) + ' %',
              why: 'max(demand ' + demand.toFixed(1) + ', fuel flow ' + fuelFlow.toFixed(1) + ') \u00d7 1.04 margin. Air is never allowed below actual fuel.' },
            { step: 'LOW select \u2192 fuel SP', value: fuelDemand.toFixed(1) + ' %',
              why: 'min(demand ' + demand.toFixed(1) + ', air flow ' + airFlow.toFixed(1) + '). Fuel is never allowed above actual air.' },
            { step: 'RATIO check (air \u00f7 fuel)', value: ratio.toFixed(3),
              why: 'Above 1.0 means air-rich, which is the safe side. O\u2082 trim fine-tunes this for efficiency.' },
            { step: 'Result', value: 'air ' + air.toFixed(1) + ' vs fuel ' + fuel.toFixed(1) + ' %',
              why: (air - fuel >= 0 ? 'Air leads by ' + (air - fuel).toFixed(1) + '% \u2014 correct.' : 'FUEL-RICH \u2014 should not happen with the selectors working.') },
          ],
          insight: fuel > air
            ? `WARNING \u2014 fuel (${fuel.toFixed(1)}%) has moved ahead of air (${air.toFixed(1)}%). With the selectors working correctly this should not occur.`
            : air - fuel > 2
              ? `Air is LEADING fuel by ${(air - fuel).toFixed(1)}% \u2014 exactly what the HIGH select on air is for. The fuel path is far slower (mill lag ~45 s) than the air path (~5 s), so fuel cannot overrun air on a load increase.`
              : `Air ${air.toFixed(1)}%, fuel ${fuel.toFixed(1)}%, excess O\u2082 ${o2.toFixed(1)}%. Air remains on the safe side of fuel.`,
        };
      },
    };
  },

  // Steam temperature: cascade beating a large lag plus dead time.
  'steam-temp-cascade': () => {
    const sprayValve = new Lag(4, 30);
    const attempTemp = new Lag(12, 340);
    const shDead = new DeadTime(25, 0.1, 540);
    const shLag = new Lag(90, 540);
    // Master is DIRECT acting: a hotter outlet must LOWER the slave target.
    const master = new PID({ kp: 1.4, ki: 0.030, outMin: 280, outMax: 420, initialOutput: 340 });
    // Slave is REVERSE acting: a hotter attemperator outlet needs MORE spray.
    const slave = new PID({ kp: 1.6, ki: 0.09, outMin: 0, outMax: 100, initialOutput: 30, reverse: true });
    return {
      trendLabel: 'SH outlet temperature (\u00b0C)', setpoint: 540,
      step(dt, sp) {
        const outlet = shLag.y;
        const masterMV = master.step(sp, outlet, dt);
        const satTemp = 340;
        const slaveSP = Math.max(satTemp, masterMV);
        const limited = masterMV < satTemp;
        const sprayCmd = slave.step(slaveSP, attempTemp.y, dt);
        const spray = sprayValve.step(sprayCmd, dt);
        const attemp = attempTemp.step(420 - spray * 1.0, dt);
        shLag.step(shDead.step(attemp) + 200, dt);
        return {
          trend: outlet,
          nodeValues: {
            'tt-out': `${outlet.toFixed(1)} \u00b0C`,
            'tic-master': `err ${(sp - outlet).toFixed(1)} \u00b0C${master.saturated ? ' SAT' : ''}`,
            'satcalc': `${satTemp} \u00b0C`,
            'maxsel': `${slaveSP.toFixed(0)} \u00b0C`,
            'tic-slave': `SP ${slaveSP.toFixed(0)} \u00b0C`,
            'tt-spray': `${attemp.toFixed(1)} \u00b0C`,
            'spray': `${spray.toFixed(1)} % open`,
            'sh': `${outlet.toFixed(1)} \u00b0C`,
          },
          strategy: 'CASCADE (two temperature loops)',
          controllers: {
            'tic-master': ctrl(master, { unit: '\u00b0C', outUnit: '\u00b0C SP', role: 'MASTER \u2014 final outlet temp' }),
            'tic-slave': ctrl(slave, { unit: '\u00b0C', outUnit: '% spray', role: 'SLAVE \u2014 after-spray temp' }),
          },
          elements: { 'spray': elem(spray, { label: 'Spray valve' }) },
          chain: [
            { step: 'Master sees outlet', value: outlet.toFixed(1) + ' \u00b0C vs SP ' + sp + ' \u00b0C', why: 'The slow, accurate loop. It never touches the valve directly.' },
            { step: 'Master output', value: masterMV.toFixed(0) + ' \u00b0C', why: 'This is a TEMPERATURE, not a valve position \u2014 it is the target the slave must hold.' },
            { step: 'MAX select vs saturation', value: slaveSP.toFixed(0) + ' \u00b0C', why: limited ? 'CLAMPED at saturation ' + satTemp + ' \u00b0C \u2014 protection against spraying water into the superheater.' : 'Above saturation (' + satTemp + ' \u00b0C), so the master value passes through.' },
            { step: 'Slave sees after-spray temp', value: attemp.toFixed(1) + ' \u00b0C vs SP ' + slaveSP.toFixed(0) + ' \u00b0C', why: 'The fast loop \u2014 responds in seconds, long before the outlet moves.' },
            { step: 'Spray valve', value: spray.toFixed(1) + ' % open', why: 'Only the slave moves the valve.' },
          ],
          insight: limited
            ? `The MAX SELECT has clamped the slave setpoint at saturation temperature (${satTemp} \u00b0C) \u2014 the protection that stops the attemperator spraying water, rather than steam, into the superheater.`
            : `Outlet ${outlet.toFixed(1)} \u00b0C against setpoint ${sp} \u00b0C. Watch the sequence: the spray valve moves, the attemperator outlet (${attemp.toFixed(0)} \u00b0C) responds within seconds, but the final outlet only follows after ~25 s of transport delay plus a 90 s thermal lag. That gap is exactly why the cascade exists.`,
        };
      },
    };
  },

  // Mill: slow grinding dynamics with an outlet-temperature loop.
  'mill-control': () => {
    const feeder = new RateLimit(2, 70);
    const millLag = new Lag(70, 70);
    const paLag = new Lag(10, 77.5);
    const tempLag = new Lag(45, 80);
    const paPid = new PID({ kp: 1.1, ki: 0.30, outMin: 20, outMax: 100, initialOutput: 77.5 });
    const tempPid = new PID({ kp: 2.0, ki: 0.06, outMin: 0, outMax: 100, initialOutput: 55 });
    return {
      trendLabel: 'Mill outlet temperature (\u00b0C)', setpoint: 80,
      step(dt, loading) {
        const coalCmd = feeder.step(loading, dt);
        const coal = millLag.step(coalCmd, dt);
        const paSP = clamp(25 + coal * 0.75, 25, 100);   // minimum PA floor
        const paCmd = paPid.step(paSP, paLag.y, dt);
        const pa = paLag.step(paCmd, dt);
        const hotPct = tempPid.step(80, tempLag.y, dt);
        const temp = tempLag.step(45 + hotPct * 0.55 - (coal - 70) * 0.12, dt);
        const ratio = coal > 1 ? pa / coal : 2;
        return {
          trend: temp,
          nodeValues: {
            'fuel-dmd': `${loading.toFixed(0)} %`,
            'feeder': `${coalCmd.toFixed(1)} %`,
            'ratio': `${ratio.toFixed(2)} air/coal`,
            'pa-fic': `SP ${paSP.toFixed(1)} %`,
            'pa-damper': `${paCmd.toFixed(1)} %`,
            'tt-out': `${temp.toFixed(1)} \u00b0C`,
            'tic': `err ${(80 - temp).toFixed(2)} \u00b0C${tempPid.saturated ? ' SAT' : ''}`,
            'split': `hot ${hotPct.toFixed(0)}%`,
            'hot-damper': `${hotPct.toFixed(1)} % open`,
            'cold-damper': `${(100 - hotPct).toFixed(1)} % open`,
            'mill': `${temp.toFixed(1)} \u00b0C`,
          },
          strategy: 'RATIO (PA/coal) + SPLIT-RANGE (hot/cold air)',
          controllers: {
            'pa-fic': ctrl(paPid, { unit: '%', outUnit: '% damper', role: 'PA flow' }),
            'tic': ctrl(tempPid, { unit: '\u00b0C', outUnit: '% hot air', role: 'Mill outlet temp' }),
          },
          elements: {
            'hot-damper': elem(hotPct, { label: 'Hot PA' }),
            'cold-damper': elem(100 - hotPct, { label: 'Cold PA' }),
            'feeder': elem(coalCmd, { label: 'Feeder' }),
          },
          chain: [
            { step: 'Fuel demand \u2192 feeder', value: coalCmd.toFixed(1) + ' %', why: 'Sets coal flow into the mill.' },
            { step: 'RATIO \u2192 PA setpoint', value: paSP.toFixed(1) + ' %',
              why: paSP <= 26 ? 'On the MINIMUM floor \u2014 PA cannot fall with coal or the pipes block.' : 'PA is scheduled from coal flow to hold the transport ratio (' + ratio.toFixed(2) + ' air/coal).' },
            { step: 'Temp controller output', value: hotPct.toFixed(0) + ' % hot',
              why: 'SPLIT RANGE: one output drives two dampers in opposite directions.' },
            { step: 'Hot / cold blend', value: hotPct.toFixed(0) + ' % hot, ' + (100 - hotPct).toFixed(0) + ' % cold',
              why: 'Blending sets the drying temperature without changing total PA flow.' },
            { step: 'Mill outlet', value: temp.toFixed(1) + ' \u00b0C vs SP 80 \u00b0C', why: 'The controlled variable.' },
          ],
          insight: temp > 88
            ? `Mill outlet at ${temp.toFixed(1)} \u00b0C, climbing toward the range where coal dust in the mill becomes a fire risk. The controller is closing hot air and opening tempering air.`
            : paSP <= 26
              ? `PA flow is on its MINIMUM floor (${paSP.toFixed(0)}%) even though coal flow is only ${coal.toFixed(0)}%. Below this floor pulverised coal settles out and blocks the burner pipes \u2014 PA does not scale down proportionally with load.`
              : `Coal ${coal.toFixed(0)}%, PA ${pa.toFixed(0)}%, ratio ${ratio.toFixed(2)}. Note the mill lag (~70 s): the feeder has already moved, but coal actually reaching the burners is still catching up.`,
        };
      },
    };
  },

  // Furnace draft: fast loop with strong FD-fan feedforward.
  'furnace-draft': () => {
    const idFan = new Lag(4, 65);
    const furnace = new Lag(2.5, -5);
    // REVERSE acting: pressure ABOVE setpoint (too positive) needs MORE ID fan.
    const pic = new PID({ kp: 2.2, ki: 0.9, outMin: -30, outMax: 30, initialOutput: 0, reverse: true });
    return {
      trendLabel: 'Furnace pressure (mmWC)', setpoint: -5,
      step(dt, airDemand) {
        const trim = pic.step(-5, furnace.y, dt);
        const idCmd = clamp(airDemand + trim, 0, 100);
        const id = idFan.step(idCmd, dt);
        const press = furnace.step(-5 + (airDemand - id) * 0.9, dt);
        return {
          trend: press,
          nodeValues: {
            'pt': `${press.toFixed(2)} mmWC`,
            'pic': `trim ${trim >= 0 ? '+' : ''}${trim.toFixed(2)}${pic.saturated ? ' SAT' : ''}`,
            'ff-air': `${airDemand.toFixed(0)} %`,
            'sum': `${idCmd.toFixed(1)} %`,
            'idfan': `${id.toFixed(1)} %`,
            'furnace': `${press.toFixed(2)} mmWC`,
          },
          strategy: 'FEEDFORWARD + trim',
          controllers: { 'pic': ctrl(pic, { unit: 'mmWC', outUnit: '% trim', role: 'Furnace draft' }) },
          elements: { 'idfan': elem(id, { label: 'ID fan' }) },
          chain: [
            { step: 'FD fan demand (feedforward)', value: airDemand.toFixed(1) + ' %',
              why: 'The bulk of the ID fan demand comes straight from the FD fan, not from a pressure error.' },
            { step: 'Draft controller trim', value: (trim >= 0 ? '+' : '') + trim.toFixed(2) + ' %',
              why: 'Only corrects the small residual. A large trim means the feedforward is mis-scaled.' },
            { step: 'Sum \u2192 ID fan demand', value: idCmd.toFixed(1) + ' %',
              why: 'feedforward ' + airDemand.toFixed(1) + ' + trim ' + (trim >= 0 ? '+' : '') + trim.toFixed(2) + ' = ' + idCmd.toFixed(1) + '.' },
            { step: 'Furnace pressure', value: press.toFixed(2) + ' mmWC vs SP \u22125 mmWC', why: 'Held slightly negative by design.' },
          ],
          insight: press > 0
            ? `FURNACE PRESSURE HAS GONE POSITIVE (${press.toFixed(1)} mmWC). Hot flue gas and flame can be pushed out through inspection doors and seals. The ID fan is being driven up to recover.`
            : press < -18
              ? `Draft strongly negative (${press.toFixed(1)} mmWC) \u2014 the implosion direction. Furnace casings are far weaker this way than most people expect.`
              : `Draft ${press.toFixed(1)} mmWC, near the \u22125 mmWC setpoint. The ID fan is tracking the FD fan almost instantly through the feedforward path; the PI is trimming only ${trim.toFixed(1)}%.`,
        };
      },
    };
  },

  // Coordinated master: fast turbine against a slow boiler.
  'coordinated-master': (mode = 'coordinated') => {
    const boiler = new Lag(180, 75);   // boiler energy release: minutes
    const turbine = new Lag(4, 75);    // governor valves: seconds
    const pressInt = new Integrator(0.055, 170, 120, 220);
    // Trim controller for coordinated mode (small authority, applied to
    // BOTH demands in opposite directions) — unchanged from before.
    const pic = new PID({ kp: 2.0, ki: 0.10, outMin: -25, outMax: 25, initialOutput: 0, reverse: true });
    // Full-authority pressure controllers for the two single-variable
    // modes, where one side is dedicated ENTIRELY to holding pressure
    // rather than sharing a small trim. Sign conventions independently
    // derived, not copied: the boiler controller is DIRECT acting (low
    // pressure -> more firing, reverse:false) and the turbine controller
    // is REVERSE acting (low pressure -> close valves to conserve steam,
    // reverse:true) — the opposite pairing from what you might guess at
    // first, and worth checking against a real plant's logic diagram
    // rather than assuming.
    const boilerPressPid = new PID({ kp: 3.0, ki: 0.12, outMin: 0, outMax: 110, initialOutput: 75, reverse: false });
    const turbPressPid = new PID({ kp: 3.0, ki: 0.12, outMin: 0, outMax: 110, initialOutput: 75, reverse: true });

    const MODE_LABEL = {
      'boiler-follow': 'BOILER FOLLOW (turbine leads load, boiler holds pressure)',
      'turbine-follow': 'TURBINE FOLLOW (boiler leads load, turbine holds pressure)',
      'coordinated': 'COORDINATED (pressure trims both demands)',
    };

    return {
      trendLabel: 'Main steam pressure (bar)', setpoint: 170,
      step(dt, loadDemand) {
        const press = pressInt.y;
        let boilerDemand, turbDemand, pTrim = null;

        if (mode === 'boiler-follow') {
          // Turbine takes the load demand directly and immediately — this
          // is the fast path a real operator sees as instant MW response.
          // The boiler has no idea load changed; it only ever reacts to
          // the pressure droop that shows up once the turbine has already
          // drawn more steam than the boiler was making.
          turbDemand = clamp(loadDemand, 0, 110);
          boilerDemand = boilerPressPid.step(170, press, dt);
        } else if (mode === 'turbine-follow') {
          // Boiler takes the load demand directly (but the boiler itself
          // is slow, so the ACTUAL firing rate still ramps over minutes).
          // The turbine's only job is to hold pressure — it will only let
          // more steam through once the boiler has actually made it.
          boilerDemand = clamp(loadDemand, 0, 110);
          turbDemand = turbPressPid.step(170, press, dt);
        } else {
          const trim = pic.step(170, press, dt);
          pTrim = trim;
          // Low pressure (negative pTrim) must RAISE firing and EASE the
          // governor valves; getting these two signs the wrong way round
          // turns the loop into positive feedback and the pressure runs away.
          boilerDemand = clamp(loadDemand - trim, 0, 110);
          turbDemand = clamp(loadDemand + trim * 0.6, 0, 110);
        }

        const b = boiler.step(boilerDemand, dt);
        const tb = turbine.step(turbDemand, dt);
        pressInt.step((b - tb) / 100, dt);

        const pressErr = 170 - press;
        return {
          trend: press,
          nodeValues: {
            'demand': `${loadDemand.toFixed(0)} %`,
            'pt-steam': `${press.toFixed(2)} bar`,
            'master': `${loadDemand.toFixed(0)} %`,
            'pic': `err ${pressErr.toFixed(2)} bar`,
            'boiler-dmd': `${boilerDemand.toFixed(1)} %`,
            'turb-dmd': `${turbDemand.toFixed(1)} %`,
            'firing': `${b.toFixed(1)} %`,
            'gv': `${tb.toFixed(1)} %`,
          },
          strategy: MODE_LABEL[mode],
          controllers: mode === 'coordinated'
            ? { 'pic': ctrl(pic, { unit: 'bar', outUnit: '% trim', role: 'Main steam pressure (trim)' }) }
            : mode === 'boiler-follow'
              ? { 'pic': ctrl(boilerPressPid, { unit: 'bar', outUnit: '% firing', role: 'Main steam pressure (boiler holds it)' }) }
              : { 'pic': ctrl(turbPressPid, { unit: 'bar', outUnit: '% valve', role: 'Main steam pressure (turbine holds it)' }) },
          elements: { 'firing': elem(b, { label: 'Firing rate' }), 'gv': elem(tb, { label: 'Governor valves' }) },
          chain: mode === 'coordinated' ? [
            { step: 'Unit load demand', value: loadDemand.toFixed(1) + ' %', why: 'Goes to BOTH boiler and turbine.' },
            { step: 'Pressure error', value: (press - 170).toFixed(2) + ' bar',
              why: 'Steam pressure is the integral of the mismatch between energy in and energy out.' },
            { step: 'Pressure trim', value: (pTrim >= 0 ? '+' : '') + pTrim.toFixed(2),
              why: 'One controller output, applied to both sides in OPPOSITE directions.' },
            { step: 'Boiler demand', value: boilerDemand.toFixed(1) + ' %',
              why: 'load ' + loadDemand.toFixed(1) + ' \u2212 trim = ' + boilerDemand.toFixed(1) + '. Low pressure raises firing.' },
            { step: 'Turbine demand', value: turbDemand.toFixed(1) + ' %',
              why: 'load ' + loadDemand.toFixed(1) + ' + trim\u00d70.6 = ' + turbDemand.toFixed(1) + '. Low pressure eases the valves.' },
          ] : mode === 'boiler-follow' ? [
            { step: 'Unit load demand', value: loadDemand.toFixed(1) + ' %', why: 'Goes STRAIGHT to the governor valves \u2014 nothing slows it down.' },
            { step: 'Turbine demand', value: turbDemand.toFixed(1) + ' %', why: 'Turbine demand = load demand, directly. Fast.' },
            { step: 'Pressure error', value: pressErr.toFixed(2) + ' bar', why: 'The turbine just took steam the boiler wasn\u2019t ready to give.' },
            { step: 'Boiler demand', value: boilerDemand.toFixed(1) + ' %', why: 'The boiler\u2019s ENTIRE job is closing this pressure error \u2014 it never sees load demand directly.' },
          ] : [
            { step: 'Unit load demand', value: loadDemand.toFixed(1) + ' %', why: 'Goes STRAIGHT to the boiler firing demand.' },
            { step: 'Boiler demand', value: boilerDemand.toFixed(1) + ' %', why: 'Boiler demand = load demand, directly \u2014 but the boiler itself still takes minutes to respond.' },
            { step: 'Pressure error', value: pressErr.toFixed(2) + ' bar', why: 'Tiny, because the turbine is defending it in real time.' },
            { step: 'Turbine demand', value: turbDemand.toFixed(1) + ' %', why: 'The turbine\u2019s ENTIRE job is holding pressure \u2014 it only lets more steam through once the boiler has actually made it.' },
          ],
          insight: mode === 'boiler-follow'
            ? (Math.abs(pressErr) > 1.5
              ? `Fast load response (valves already at ${tb.toFixed(0)}%) but pressure is ${Math.abs(pressErr).toFixed(1)} bar ${press < 170 ? 'below' : 'above'} setpoint \u2014 the classic Boiler Follow trade-off. The boiler (180 s) is still catching up to steam the turbine already took.`
              : `Load ${loadDemand.toFixed(0)}%, pressure recovered to ${press.toFixed(1)} bar. Boiler has caught up with what the turbine already took.`)
            : mode === 'turbine-follow'
              ? (Math.abs(loadDemand - tb) > 3
                ? `Pressure is rock-steady (${press.toFixed(1)} bar) but actual output (valves at ${tb.toFixed(0)}%) is still far from the ${loadDemand.toFixed(0)}% demanded \u2014 the classic Turbine Follow trade-off. The turbine won\u2019t take more steam than the boiler (180 s) has actually made.`
                : `Load ${loadDemand.toFixed(0)}%, pressure held at ${press.toFixed(1)} bar throughout. Boiler has caught up \u2014 output now matches demand.`)
              : (Math.abs(press - 170) > 1.5
                ? `Main steam pressure is ${Math.abs(press - 170).toFixed(1)} bar ${press > 170 ? 'ABOVE' : 'BELOW'} setpoint. The turbine (4 s) moves far faster than the boiler (180 s), so energy in and energy out are mismatched \u2014 and steam pressure is the integral of that mismatch. The pressure PI is trimming both demands to close the gap.`
                : `Load ${loadDemand.toFixed(0)}%, firing ${b.toFixed(0)}%, valves ${tb.toFixed(0)}%, pressure ${press.toFixed(1)} bar. Boiler and turbine matched \u2014 coordinated control working as intended.`),
        };
      },
    };
  },

  // Turbine bypass: fast-acting, with a genuine transient on trip.
  'turbine-bypass': () => {
    const hpValve = new Lag(2.5, 10);
    const lpValve = new Lag(2.5, 9);
    const pressInt = new Integrator(1.1, 170, 120, 240);
    const pic = new PID({ kp: 2.6, ki: 0.5, outMin: 0, outMax: 100, initialOutput: 10, reverse: true });
    return {
      trendLabel: 'Main steam pressure (bar)', setpoint: 170,
      step(dt, turbineLoad) {
        const tripped = turbineLoad < 5;
        const press = pressInt.y;
        const pidOut = pic.step(170, press, dt);
        // HIGH SELECT: fast-open overrides normal PID action on a trip.
        const demand = tripped ? Math.max(pidOut, 100) : pidOut;
        const hp = hpValve.step(demand, dt);
        const lp = lpValve.step(demand * 0.9, dt);
        // Bypass is sized for essentially full boiler flow — that is what
        // lets the unit ride through a turbine trip without shutting down.
        pressInt.step((100 - turbineLoad - hp * 1.02) / 100, dt);
        return {
          trend: press,
          nodeValues: {
            'pt-ms': `${press.toFixed(2)} bar`,
            'trip': tripped ? 'TRIPPED' : 'healthy',
            'pic-hp': `err ${(170 - press).toFixed(2)}${pic.saturated ? ' SAT' : ''}`,
            'hs': `${demand.toFixed(1)} %`,
            'hp-bp': `${hp.toFixed(1)} % open`,
            'spray1': `${(hp * 0.6).toFixed(1)} % open`,
            'pic-lp': tripped ? 'FAST OPEN' : `${(demand * 0.9).toFixed(1)} %`,
            'lp-bp': `${lp.toFixed(1)} % open`,
            'cond': tripped ? 'full dump' : `${lp.toFixed(0)} % dump`,
          },
          strategy: 'PRESSURE CONTROL + HIGH-SELECT OVERRIDE',
          controllers: { 'pic-hp': ctrl(pic, { unit: 'bar', outUnit: '% bypass', role: 'Main steam pressure' }) },
          elements: { 'hp-bp': elem(hp, { label: 'HP bypass' }), 'lp-bp': elem(lp, { label: 'LP bypass' }) },
          chain: [
            { step: 'Pressure controller output', value: pidOut.toFixed(1) + ' %', why: 'Normal modulating control.' },
            { step: 'Trip fast-open signal', value: tripped ? '100 % (ACTIVE)' : 'not active', why: 'On a trip this bypasses normal PID action entirely.' },
            { step: 'HIGH select', value: demand.toFixed(1) + ' %', why: 'max(PID ' + pidOut.toFixed(1) + ', fast-open ' + (tripped ? '100' : '0') + '). Whichever demands MORE bypass wins.' },
            { step: 'Bypass valves', value: 'HP ' + hp.toFixed(0) + ' %, LP ' + lp.toFixed(0) + ' %', why: 'Route steam around the turbine.' },
            { step: 'Main steam pressure', value: press.toFixed(2) + ' bar vs SP 170 bar', why: 'Held off the safety valves.' },
          ],
          insight: tripped
            ? `TURBINE TRIP. The fast-open signal has overridden the PID through the HIGH SELECT and both bypasses are driving wide open. Watch the trend: pressure rises as the governor valves slam shut, then the bypass catches it before the safety valves lift. Without the bypass this excursion would keep going.`
            : press > 174
              ? `Pressure rising \u2014 the turbine is not taking all the steam the boiler is making, and the bypass is opening to absorb the surplus.`
              : `Turbine taking ${turbineLoad.toFixed(0)}%, bypass ${hp.toFixed(0)}% open, pressure ${press.toFixed(1)} bar. Normal modulating control.`,
        };
      },
    };
  },

  // Deaerator: two interacting integrating loops.
  'deaerator-level': () => {
    const lvlInt = new Integrator(0.7, 0, -600, 600);
    const makeupV = new Lag(4, 100);
    const pressLag = new Lag(30, 5.0);
    const peggingV = new Lag(6, 45);
    const lic = new PID({ kp: 1.4, ki: 0.10, outMin: 0, outMax: 100, initialOutput: 100 });
    const pic = new PID({ kp: 8, ki: 1.2, outMin: 0, outMax: 100, initialOutput: 45 });
    return {
      trendLabel: 'Deaerator level (mm)', setpoint: 0,
      step(dt, drawOff) {
        const level = lvlInt.y;
        const mk = makeupV.step(lic.step(0, level, dt), dt);
        // Valve sized with ~30% margin above normal flow at fully open --
        // standard practice, and what actually lets the loop absorb an
        // increased draw-off instead of running out of valve travel.
        const mkFlow = mk * 1.3;
        lvlInt.step((mkFlow - drawOff) / 100, dt);
        const pg = peggingV.step(pic.step(5.0, pressLag.y, dt), dt);
        const press = pressLag.step(3.2 + pg * 0.042 - (drawOff - 100) * 0.004, dt);
        const npsh = 12 + (press - 5.0) * 8 + level * 0.006;
        return {
          trend: level,
          nodeValues: {
            'lt': `${level >= 0 ? '+' : ''}${level.toFixed(0)} mm`,
            'pt': `${press.toFixed(3)} bar`,
            'lic': `err ${(-level).toFixed(1)}${lic.saturated ? ' SAT' : ''}`,
            'pic': `err ${(5.0 - press).toFixed(3)}`,
            'lcv': `${mk.toFixed(1)} % open`,
            'pcv': `${pg.toFixed(1)} % open`,
            'da': `${press.toFixed(3)} bar`,
            'bfp': `NPSH ${npsh.toFixed(2)} m`,
          },
          strategy: 'TWO INDEPENDENT LOOPS (level + pressure)',
          controllers: {
            'lic': ctrl(lic, { unit: 'mm', outUnit: '% makeup', role: 'Storage level' }),
            'pic': ctrl(pic, { unit: 'bar', outUnit: '% pegging', role: 'Deaerator pressure' }),
          },
          elements: { 'lcv': elem(mk, { label: 'Makeup valve' }), 'pcv': elem(pg, { label: 'Pegging steam' }) },
          chain: [
            { step: 'Level controller', value: level.toFixed(0) + ' mm vs SP 0 mm', why: 'Integrating \u2014 only the controller brings it back.' },
            { step: 'Makeup valve', value: mk.toFixed(1) + ' % open', why: 'Against a draw-off of ' + drawOff.toFixed(0) + ' %.' },
            { step: 'Pressure controller', value: press.toFixed(3) + ' bar vs SP 5.000 bar', why: 'Separate loop, same vessel.' },
            { step: 'Pegging steam valve', value: pg.toFixed(1) + ' % open', why: 'Defends the pressure that provides pump suction head.' },
            { step: 'BFP NPSH margin', value: npsh.toFixed(2) + ' m', why: 'The number that actually matters \u2014 both loops protect it.' },
          ],
          insight: npsh < 8
            ? `NPSH MARGIN DOWN TO ${npsh.toFixed(1)} m. The feed pumps are approaching cavitation. Deaerator level and pressure both feed BFP suction head \u2014 lose either and the pumps suffer within seconds.`
            : Math.abs(level) > 120
              ? `Level ${level > 0 ? 'high' : 'low'} at ${level.toFixed(0)} mm. This is an INTEGRATING process \u2014 makeup is ${mk.toFixed(0)}% against a draw-off of ${drawOff.toFixed(0)}%, and until those balance the level keeps moving.`
              : `Level ${level.toFixed(0)} mm, pressure ${press.toFixed(2)} bar, NPSH margin ${npsh.toFixed(1)} m. Stable, with comfortable pump suction head.`,
        };
      },
    };
  },

  // HP heater level: integrating, with an independent HH trip.
  'hp-heater-level': () => {
    const lvlInt = new Integrator(1.0, 0, -400, 400);
    const drainV = new Lag(3, 45);
    const lic = new PID({ kp: 1.1, ki: 0.16, outMin: 0, outMax: 100, initialOutput: 45, reverse: true });
    let tripped = false;
    return {
      trendLabel: 'Heater level (mm)', setpoint: 0,
      step(dt, extractionFlow) {
        const level = lvlInt.y;
        if (level >= 150) tripped = true;
        if (tripped && level < 60) tripped = false;   // reset with hysteresis
        const cmd = lic.step(0, level, dt);
        const drain = drainV.step(cmd, dt);
        const condensing = tripped ? 0 : extractionFlow * 0.85;
        lvlInt.step((condensing - drain * 0.85) / 30, dt);
        return {
          trend: level,
          nodeValues: {
            'lt': `${level >= 0 ? '+' : ''}${level.toFixed(0)} mm`,
            'ft-extr': `${extractionFlow.toFixed(0)} %`,
            'lic': `err ${(-level).toFixed(1)}${lic.saturated ? ' SAT' : ''}`,
            'sum': `${cmd.toFixed(1)} %`,
            'lcv': `${drain.toFixed(1)} % open`,
            'heater': `${level >= 0 ? '+' : ''}${level.toFixed(0)} mm`,
            'hh-trip': tripped ? 'TRIPPED' : 'armed (150 mm)',
            'nrv': tripped ? 'CLOSED' : 'open',
          },
          strategy: '3-ELEMENT + INDEPENDENT TRIP',
          controllers: { 'lic': ctrl(lic, { unit: 'mm', outUnit: '% drain', role: 'Heater level' }) },
          elements: { 'lcv': elem(drain, { label: 'Drain valve' }) },
          chain: [
            { step: 'Extraction flow (feedforward)', value: extractionFlow.toFixed(0) + ' %', why: 'Predicts the condensing rate before level moves.' },
            { step: 'Level controller', value: level.toFixed(0) + ' mm vs SP 0 mm', why: 'Trims for the residual error.' },
            { step: 'Drain valve', value: drain.toFixed(1) + ' % open', why: 'Removes condensate to hold level.' },
            { step: 'HH trip (independent)', value: tripped ? 'TRIPPED' : 'armed at 150 mm', why: 'Deliberately NOT part of the control loop \u2014 if the loop is what failed, protection must not depend on it.' },
            { step: 'Extraction NRV', value: tripped ? 'CLOSED' : 'open', why: 'Isolates the heater to stop water reaching the turbine.' },
          ],
          insight: tripped
            ? `HIGH-HIGH TRIP OPERATED. The extraction non-return valve has closed and the heater is isolated. This acted through the INDEPENDENT protection path, not the level controller \u2014 deliberately so, because if the control loop is what failed, protection must not depend on it.`
            : level > 90
              ? `Level ${level.toFixed(0)} mm and rising toward the 150 mm HH trip, drain valve at ${drain.toFixed(0)}%. If the drain cannot keep up, the trip isolates the heater before water can back up the extraction line into the turbine.`
              : `Level ${level.toFixed(0)} mm, drain valve ${drain.toFixed(0)}%, extraction ${extractionFlow.toFixed(0)}%. Under control.`,
        };
      },
    };
  },

  // Hotwell: split-range with a genuine deadband.
  'condenser-hotwell': () => {
    const lvlInt = new Integrator(0.5, 0, -500, 500);
    const mkV = new Lag(4, 0);
    const rjV = new Lag(4, 0);
    const lic = new PID({ kp: 0.55, ki: 0.05, outMin: 0, outMax: 100, initialOutput: 50, reverse: true });
    return {
      trendLabel: 'Hotwell level (mm)', setpoint: 0,
      step(dt, imbalance) {
        const level = lvlInt.y;
        const mv = lic.step(0, level, dt);
        const mkCmd = mv < 45 ? clamp((45 - mv) * 2.2, 0, 100) : 0;
        const rjCmd = mv > 55 ? clamp((mv - 55) * 2.2, 0, 100) : 0;
        const mk = mkV.step(mkCmd, dt);
        const rj = rjV.step(rjCmd, dt);
        lvlInt.step((mk - rj - imbalance) / 100, dt);
        const npsh = 9 + level * 0.012;
        const inDead = mkCmd === 0 && rjCmd === 0;
        return {
          trend: level,
          nodeValues: {
            'lt': `${level >= 0 ? '+' : ''}${level.toFixed(0)} mm`,
            'lic': `MV ${mv.toFixed(1)} %${lic.saturated ? ' SAT' : ''}`,
            'split': inDead ? 'DEADBAND' : mk > rj ? 'makeup band' : 'reject band',
            'makeup': `${mk.toFixed(1)} % open`,
            'reject': `${rj.toFixed(1)} % open`,
            'hotwell': `${level >= 0 ? '+' : ''}${level.toFixed(0)} mm`,
            'cep': `NPSH ${npsh.toFixed(2)} m`,
          },
          strategy: 'SPLIT-RANGE with DEADBAND',
          controllers: { 'lic': ctrl(lic, { unit: 'mm', outUnit: '% MV', role: 'Hotwell level' }) },
          elements: { 'makeup': elem(mk, { label: 'Makeup' }), 'reject': elem(rj, { label: 'Reject' }) },
          chain: [
            { step: 'Level controller output', value: mv.toFixed(1) + ' %', why: 'ONE output drives TWO valves across different parts of its range.' },
            { step: 'Below 45 % \u2192 makeup', value: mk.toFixed(1) + ' % open', why: 'Falling level opens makeup from storage.' },
            { step: '45\u201355 % \u2192 deadband', value: inDead ? 'IN DEADBAND \u2014 both shut' : 'outside deadband', why: 'The gap is deliberate: without it both valves sit part-open and cycle water back and forth.' },
            { step: 'Above 55 % \u2192 reject', value: rj.toFixed(1) + ' % open', why: 'Rising level dumps back to storage.' },
            { step: 'CEP NPSH margin', value: npsh.toFixed(2) + ' m', why: 'Low level starves the condensate pumps.' },
          ],
          insight: npsh < 6
            ? `CEP NPSH margin down to ${npsh.toFixed(1)} m. Makeup is at ${mk.toFixed(0)}% but level is still falling \u2014 the condensate pumps are heading toward cavitation.`
            : inDead
              ? `Level ${level.toFixed(0)} mm sits inside the DEADBAND, so BOTH valves are shut. That gap is deliberate: without it, makeup and reject would both sit part-open and cycle water back and forth continuously.`
              : `Level ${level.toFixed(0)} mm, ${mk > rj ? 'makeup ' + mk.toFixed(0) + '%' : 'reject ' + rj.toFixed(0) + '%'}. Only one valve acts at a time \u2014 never both.`,
        };
      },
    };
  },

  // AVR: fast electrical loop with hard limiters.
  'avr-excitation': () => {
    const exciter = new Lag(0.35, 85);
    const genV = new Lag(1.2, 100);
    const avr = new PID({ kp: 22, ki: 45, outMin: 40, outMax: 140, initialOutput: 85 });
    return {
      trendLabel: 'Terminal voltage (%)', setpoint: 100,
      step(dt, reactiveDemand) {
        const oel = 110, uel = 55;
        const vTerm = genV.y;
        const avrOut = avr.step(100, vTerm - (reactiveDemand - 85) * 0.10, dt);
        const oelActive = avrOut >= oel, uelActive = avrOut <= uel;
        const limited = clamp(avrOut, uel, oel);   // limiters override the AVR
        const field = exciter.step(limited, dt);
        genV.step(100 + (field - 85) * 0.12 - (reactiveDemand - 85) * 0.02, dt);
        const mvar = (field - 80) * 4.5;
        return {
          trend: vTerm,
          nodeValues: {
            'vt': `${vTerm.toFixed(2)} %`,
            'sp': '100.00 %',
            'avr': `err ${(100 - vTerm).toFixed(3)} %${avr.saturated ? ' SAT' : ''}`,
            'limiters': oelActive ? 'OEL ACTIVE' : uelActive ? 'UEL ACTIVE' : 'not limiting',
            'pss': 'damping',
            'exciter': `${field.toFixed(2)} % field`,
            'gen': `${mvar >= 0 ? '+' : ''}${mvar.toFixed(1)} MVAr`,
            'ct': `${field.toFixed(1)} %`,
          },
          strategy: 'VOLTAGE PID + OVERRIDE LIMITERS',
          controllers: { 'avr': ctrl(avr, { unit: '%', outUnit: '% field', role: 'Terminal voltage' }) },
          elements: { 'exciter': elem(field, { label: 'Field current', min: 40, max: 140 }) },
          chain: [
            { step: 'AVR compares voltage', value: vTerm.toFixed(2) + ' % vs SP 100.00 %', why: 'The main regulating loop.' },
            { step: 'AVR asks for field', value: avrOut.toFixed(1) + ' %', why: 'What the voltage loop wants, before limiting.' },
            { step: 'Limiters', value: oelActive ? 'OEL clamping at ' + oel + ' %' : uelActive ? 'UEL clamping at ' + uel + ' %' : 'not limiting', why: 'Limiters OVERRIDE the AVR. They hold the machine at its capability boundary \u2014 they are not trips.' },
            { step: 'Field current delivered', value: field.toFixed(1) + ' %', why: 'What the exciter actually supplies.' },
            { step: 'Reactive output', value: (mvar >= 0 ? '+' : '') + mvar.toFixed(0) + ' MVAr', why: 'Once synchronised, field current sets MVAr rather than voltage.' },
          ],
          insight: oelActive
            ? `OVER-EXCITATION LIMITER ACTIVE \u2014 field current clamped at ${oel}%. The AVR is still calling for more, but the limiter overrides it; sustained over-excitation overheats the rotor winding. This is a LIMITER holding the machine at its boundary, not a trip \u2014 loss-of-field and over-excitation protections sit behind it separately.`
            : uelActive
              ? `UNDER-EXCITATION LIMITER ACTIVE at ${uel}%. Running too far under-excited heats the stator end-core and moves the machine toward its stability limit.`
              : `Terminal voltage ${vTerm.toFixed(2)}%, field ${field.toFixed(0)}%, ${mvar >= 0 ? 'exporting' : 'absorbing'} ${Math.abs(mvar).toFixed(0)} MVAr. Notice how fast this loop is compared with every thermal loop \u2014 the exciter time constant is well under a second.`,
        };
      },
    };
  },

  // Fire/water ratio: parallel feedforward, no drum buffer, so a feedwater
  // temperature upset shows up in steam temperature almost immediately.
  'firewater-ratio': () => {
    const firingLag = new Lag(20, 75);
    const fwLag = new Lag(15, 75);
    const fwTempLag = new Lag(60, 0);
    const tic = new PID({ kp: 1.1, ki: 0.045, outMin: -15, outMax: 15, initialOutput: 0 });
    const outletLag = new Lag(25, 597);
    const sprayValve = new Lag(3, 20);
    return {
      trendLabel: 'Final steam temperature (\u00b0C)', setpoint: 597,
      step(dt, fwTempDevInput) {
        const fwTempDev = fwTempLag.step(fwTempDevInput, dt);
        const outlet = outletLag.y;
        const trim = tic.step(597, outlet, dt);
        const firingCmd = 75 + trim - fwTempDev * 0.05;
        const fwCmd = 75;
        const firing = firingLag.step(firingCmd, dt);
        const fw = fwLag.step(fwCmd, dt);
        const ratio = fw > 1 ? firing / fw : 1;
        const sprayCmd = Math.min(100, Math.max(0, 20 - trim * 3));
        const spray = sprayValve.step(sprayCmd, dt);
        // No drum buffer: outlet responds with only a modest lag, unlike the
        // 90 s thermal mass in the drum-boiler cascade loop.
        // Cold feedwater consumes more heat just reaching saturation, which
        // LOWERS outlet temperature -- fwTempDev negative must subtract here.
        outletLag.step(597 + (ratio - 1) * 400 + fwTempDev * 1.1 - spray * 0.15, dt);
        return {
          trend: outlet,
          nodeValues: {
            'load': '75 %',
            'firing-ff': `${firingCmd.toFixed(1)} %`,
            'fw-ff': `${fwCmd.toFixed(1)} %`,
            'fwtemp': `${fwTempDev >= 0 ? '+' : ''}${fwTempDev.toFixed(1)} \u00b0C`,
            'ratio': `${ratio.toFixed(3)}`,
            'tic': `trim ${trim >= 0 ? '+' : ''}${trim.toFixed(2)}${tic.saturated ? ' SAT' : ''}`,
            'tt-out': `${outlet.toFixed(1)} \u00b0C`,
            'spray': `${spray.toFixed(0)} % open`,
            'boiler': `${outlet.toFixed(1)} \u00b0C`,
          },
          strategy: 'PARALLEL FEEDFORWARD + RATIO TRIM (no drum buffer)',
          controllers: {
            'tic': ctrl(tic, { unit: '\u00b0C', outUnit: '% ratio trim', role: 'Steam temperature' }),
          },
          elements: { 'firing-ff': elem(firing, { min: 40, max: 110, label: 'Firing rate' }), 'spray': elem(spray, { label: 'Spray valve' }) },
          chain: [
            { step: 'Feedwater temperature deviation', value: `${fwTempDev >= 0 ? '+' : ''}${fwTempDev.toFixed(1)} \u00b0C`, why: 'Colder feedwater consumes more of the available heat just reaching saturation.' },
            { step: 'Firing & feedwater demand', value: 'both from load, in PARALLEL', why: 'Neither is cascaded from the other \u2014 unlike a drum boiler, there is no level loop to hide a mismatch.' },
            { step: 'Fire/water ratio', value: ratio.toFixed(3), why: 'The PRIMARY handle for steam temperature on a once-through boiler.' },
            { step: 'Spray (fast trim only)', value: spray.toFixed(0) + '% open', why: 'A small polish on top of a ratio that is already close \u2014 not the main mechanism.' },
            { step: 'Final steam temperature', value: outlet.toFixed(1) + ' \u00b0C', why: 'Responds within tens of seconds, not the ~90 s seen in a drum boiler with real thermal storage.' },
          ],
          insight: Math.abs(fwTempDev) > 8
            ? `Feedwater is ${Math.abs(fwTempDev).toFixed(1)} \u00b0C ${fwTempDev < 0 ? 'colder' : 'hotter'} than normal. Watch how directly this shows up in outlet temperature (${outlet.toFixed(0)} \u00b0C) \u2014 there is no drum to average it out. The ratio has moved to ${ratio.toFixed(3)} to compensate.`
            : `Outlet ${outlet.toFixed(1)} \u00b0C against setpoint 597 \u00b0C. Ratio holding near 1.000, spray only doing a small trim \u2014 this is the fire/water ratio doing its job as the primary temperature handle.`,
        };
      },
    };
  },

  // Sliding pressure: the pressure SETPOINT itself moves with load through
  // the middle of the range, with governor valves held near wide open.
  'sliding-pressure': () => {
    const pMin = 120, pRated = 170;
    const pressLag = new Lag(60, pMin);
    const valveLag = new Lag(6, 55);
    const pic = new PID({ kp: 1.6, ki: 0.03, outMin: -20, outMax: 20, initialOutput: 0 });
    return {
      trendLabel: 'Main steam pressure (bar)', setpoint: null,
      step(dt, load) {
        let pSP, regime;
        if (load <= 70) { pSP = pMin; regime = 'FIXED (below sliding band)'; }
        else if (load >= 90) { pSP = pRated; regime = 'FIXED (reserve band)'; }
        else { pSP = pMin + (pRated - pMin) * ((load - 70) / 20); regime = 'SLIDING'; }

        const press = pressLag.y;
        const trim = pic.step(pSP, press, dt);
        const firingCmd = load + trim;
        pressLag.step(pSP + (firingCmd - load) * 0.3, dt);

        let valveTarget;
        if (regime === 'SLIDING') valveTarget = 95;
        else if (load < 70) valveTarget = 55 + (load - 40) * 0.5;
        else valveTarget = Math.max(60, 100 - (load - 90) * 3);
        const valve = valveLag.step(valveTarget, dt);
        const throttleLossPct = Math.max(0, (100 - valve) * 0.18);

        return {
          trend: press,
          nodeValues: {
            'load': `${load.toFixed(0)} %`,
            'schedule': `${pSP.toFixed(1)} bar`,
            'pic': `SP ${pSP.toFixed(1)}${pic.saturated ? ' SAT' : ''}`,
            'pt': `${press.toFixed(1)} bar`,
            'firing': `${firingCmd.toFixed(1)} %`,
            'gv': `${valve.toFixed(0)} % open`,
            'turbine': `${load.toFixed(0)} % load`,
          },
          strategy: regime,
          controllers: { 'pic': ctrl(pic, { unit: 'bar', outUnit: '% firing trim', role: 'Boiler pressure' }) },
          elements: { 'firing': elem(firingCmd, { min: 30, max: 110, label: 'Firing rate' }), 'gv': elem(valve, { label: 'Governor valves' }) },
          chain: [
            { step: 'Load demand', value: load.toFixed(0) + ' %', why: 'Drives the pressure schedule directly.' },
            { step: 'Load \u2192 pressure schedule', value: pSP.toFixed(1) + ' bar (' + regime + ')', why: 'Fixed below 70%, sliding 70\u201390%, fixed again above 90% as a reserve.' },
            { step: 'Boiler pressure PID', value: 'trim ' + (trim >= 0 ? '+' : '') + trim.toFixed(2) + '%', why: 'Trims firing to track the CURRENT schedule point, which itself moves with load.' },
            { step: 'Governor valve position', value: valve.toFixed(0) + '% open', why: regime === 'SLIDING' ? 'Held near wide open \u2014 minimal throttling loss.' : 'Modulating to control load precisely at this end of the range.' },
            { step: 'Throttling loss', value: throttleLossPct.toFixed(1) + ' %', why: 'What a fixed-pressure design would waste here that this strategy avoids.' },
          ],
          insight: regime === 'SLIDING'
            ? `Sliding pressure band. Governor valves held near wide open (${valve.toFixed(0)}%), pressure itself matching steam supply to turbine demand. Throttling loss only about ${throttleLossPct.toFixed(1)}% \u2014 a fixed-pressure unit would waste more at this same load.`
            : load < 70
              ? `Below the sliding band. Pressure held at its fixed minimum (${pMin} bar); valves modulate more to control load here.`
              : `Above the sliding band \u2014 pressure deliberately fixed at ${pRated} bar again. This is a genuine reserve: if load jumps right now, the valves can open further and deliver more steam instantly, without waiting for the boiler to raise pressure.`,
        };
      },
    };
  },

  // Condenser vacuum: base pressure is a hard physical floor set by cooling
  // water temperature (via real IAPWS-IF97 saturation pressure -- not an
  // approximation), plus a gas-blanketing term that accumulates from a
  // constant background air in-leakage and is removed by ejector capacity.
  // The controller can only ever manage the second term.
  'condenser-vacuum': () => {
    const ejectorPid = new PID({ kp: 1.8, ki: 0.12, outMin: 20, outMax: 100, initialOutput: 55, reverse: true });
    const gasBlanket = new Integrator(0.018, 1.5, 0, 6); // kPa of extra pressure from uncleared gas
    const AIR_INLEAK_RATE = 1.0; // kPa/min-equivalent worth of gas arriving, constant background leakage
    const TTD_C = 4; // terminal temperature difference, clean condenser
    const CW_RISE_C = 8; // typical CW temperature rise across the tube bundle

    function basePressureKPa(cwTempC) {
      const condensingTempC = cwTempC + CW_RISE_C + TTD_C;
      return steam.psat(condensingTempC + 273.15) * 1000;
    }

    return {
      trendLabel: 'Condenser pressure (kPa abs)', setpoint: null,
      step(dt, cwTempC) {
        const base = basePressureKPa(cwTempC);
        const setpointKPa = basePressureKPa(25) + 0.3; // realistic target: the clean, minimal-gas floor at a normal CW temp, plus a small margin
        const press = base + gasBlanket.y;
        const ejectorPct = ejectorPid.step(setpointKPa, press, dt);
        // Ejector removal scales with its capacity; a fixed background
        // leak keeps arriving regardless of what the ejector is doing.
        const removalRate = (ejectorPct / 100) * 1.6;
        gasBlanket.step(AIR_INLEAK_RATE - removalRate, dt);

        const achievableFloor = base; // what the plant COULD reach with zero gas blanketing
        const excessOverFloor = press - achievableFloor;

        return {
          trend: press,
          nodeValues: {
            'cwtemp': `${cwTempC.toFixed(0)} \u00b0C`,
            'condenser': `${press.toFixed(2)} kPa`,
            'pt': `${press.toFixed(2)} kPa`,
            'pic': `SP ${setpointKPa.toFixed(2)} kPa`,
            'ejector': `${ejectorPct.toFixed(0)} % capacity`,
          },
          controllers: { 'pic': ctrl(ejectorPid, { unit: 'kPa', outUnit: '% capacity', role: 'Condenser pressure (ejector)' }) },
          elements: { 'ejector': elem(ejectorPct, { label: 'Ejector capacity' }) },
          chain: [
            { step: 'Cooling water inlet temperature', value: cwTempC.toFixed(1) + ' \u00b0C', why: 'Sets the condensing temperature, and with it, the pressure FLOOR \u2014 no controller can move this.' },
            { step: 'Achievable pressure floor', value: achievableFloor.toFixed(2) + ' kPa', why: 'IAPWS-IF97 saturation pressure at condensing temperature. The best this condenser could ever do at this CW temperature, with zero non-condensable gas.' },
            { step: 'Gas blanketing', value: '+' + gasBlanket.y.toFixed(2) + ' kPa', why: 'Non-condensable gas the ejector has not yet cleared \u2014 arrives at a steady background rate, removed only by ejector capacity.' },
            { step: 'Actual condenser pressure', value: press.toFixed(2) + ' kPa', why: 'Floor + gas blanketing. This is what the plant actually sees.' },
            { step: 'Ejector capacity', value: ejectorPct.toFixed(0) + ' %', why: 'The PIC\u2019s entire authority is over this term \u2014 it cannot touch the floor itself.' },
          ],
          insight: excessOverFloor > 0.8
            ? `Pressure is ${excessOverFloor.toFixed(1)} kPa ABOVE the achievable floor for this cooling water temperature \u2014 gas blanketing has built up faster than the ejector (at ${ejectorPct.toFixed(0)}%) can clear it. This is the failure mode a real ejector/vacuum-pump capacity check exists to catch.`
            : `Pressure ${press.toFixed(2)} kPa, within ${excessOverFloor.toFixed(2)} kPa of the achievable floor for ${cwTempC.toFixed(0)}\u00b0C cooling water. Ejector holding gas blanketing to a minimum \u2014 the plant is sitting at the floor, not above it.`,
        };
      },
    };
  },
};

export const NODE_STYLES = {
  sensor: { color: 'var(--cyan)', shape: 'circle', hint: 'Measurement / transmitter' },
  controller: { color: 'var(--amber)', shape: 'rect', hint: 'PID controller' },
  compute: { color: 'var(--blue)', shape: 'diamond', hint: 'Function block (sum, select, ratio, f(x))' },
  actuator: { color: 'var(--green)', shape: 'rect', hint: 'Final control element' },
  process: { color: 'var(--text-faint)', shape: 'rect', hint: 'Physical process' },
  demand: { color: 'var(--red)', shape: 'rect', hint: 'External demand / setpoint' },
};

/** Edge style -> colour and dash pattern. */
// PV (measurement into a controller) and MV (command out to an actuator)
// are the two most structurally important signal types in any loop -- yet
// most edges carrying them were left on the generic 'normal' style, the
// dimmest colour in the whole palette. That inverted the visual hierarchy:
// the wires most worth reading were the hardest to see. 'pv' and 'mv' give
// them their own clear, consistent treatment; drawLoop() in app.js applies
// these automatically to any edge labelled 'PV' or 'MV' that doesn't
// already have an explicit style, so all 13 loops benefit without needing
// every edge definition hand-edited.
export const EDGE_STYLES = {
  normal: { color: 'var(--line)', dash: '', label: 'Signal' },
  pv: { color: 'var(--cyan)', dash: '4 3', label: 'Measurement (PV)' },
  mv: { color: 'var(--green)', dash: '', label: 'Command (MV)' },
  feedback: { color: 'var(--cyan)', dash: '4 3', label: 'Measurement feedback' },
  cascade: { color: 'var(--amber)', dash: '', label: 'Cascade setpoint' },
  ff: { color: 'var(--blue)', dash: '6 3', label: 'Feedforward' },
  crosslimit: { color: 'var(--red)', dash: '6 3', label: 'Cross-limit' },
};
