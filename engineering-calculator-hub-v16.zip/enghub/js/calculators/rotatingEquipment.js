// rotatingEquipment.js — pump, fan and bearing calculations for real
// plant rotating machinery work.

// ============================================================
// 1. CENTRIFUGAL PUMP: NPSH AVAILABLE & AFFINITY LAWS
// ============================================================

/**
 * NPSH available at the pump suction, in meters of head.
 * NPSHa = (source pressure - vapor pressure) / (rho*g) + static head - friction loss
 * Static head is POSITIVE for flooded suction (source above pump
 * centerline), NEGATIVE for suction lift (source below pump centerline).
 */
export function npshAvailable({
  sourcePressureBarA, vaporPressureBarA, specificGravity,
  staticHeadM, frictionLossM,
}) {
  if (!(sourcePressureBarA > 0)) throw new Error('Source pressure must be greater than zero (absolute).');
  if (!(vaporPressureBarA >= 0)) throw new Error('Vapor pressure cannot be negative.');
  if (!(specificGravity > 0)) throw new Error('Specific gravity must be greater than zero.');
  if (!(frictionLossM >= 0)) throw new Error('Friction loss cannot be negative.');
  if (sourcePressureBarA <= vaporPressureBarA) {
    throw new Error('Source pressure must exceed vapor pressure, or the fluid is already boiling at the source.');
  }
  // 1 bar = 10.197 m of head for water (SG=1); scales inversely with SG.
  const pressureHeadM = ((sourcePressureBarA - vaporPressureBarA) * 10.197) / specificGravity;
  const npshaM = pressureHeadM + staticHeadM - frictionLossM;
  return {
    pressureHeadM, npshaM,
    note: npshaM <= 0 ? 'NPSH available is zero or negative \u2014 the pump cannot run without cavitating under these conditions.' : undefined,
  };
}

/** Compares NPSH available against NPSH required (from the pump curve) with margin. */
export function npshMarginCheck(npshAvailableM, npshRequiredM, marginM = 0.6) {
  if (!(npshAvailableM > -1e9)) throw new Error('NPSH available must be a number.');
  if (!(npshRequiredM > 0)) throw new Error('NPSH required (from the pump curve) must be greater than zero.');
  if (!(marginM >= 0)) throw new Error('Margin cannot be negative.');
  const marginActualM = npshAvailableM - npshRequiredM;
  return {
    marginActualM,
    adequate: marginActualM >= marginM,
    note: marginActualM < 0
      ? 'NPSHa is BELOW NPSHr \u2014 the pump will cavitate. Increase source elevation/pressure, reduce suction friction loss, or select a pump with lower NPSHr.'
      : marginActualM < marginM
        ? `Margin is only ${marginActualM.toFixed(2)} m, below the commonly used ${marginM} m minimum \u2014 acceptable in some services but worth reviewing against the specific pump vendor's recommendation.`
        : 'Margin meets the commonly used minimum. Hydraulic institute guidance for critical services may call for a larger margin \u2014 check vendor and site standards.',
  };
}

/**
 * Pump affinity laws for a fixed impeller diameter, speed change only:
 *   Q2/Q1 = N2/N1        H2/H1 = (N2/N1)^2        P2/P1 = (N2/N1)^3
 */
export function pumpAffinityLaws({ flowM3H, headM, powerKw, speedRpm1, speedRpm2 }) {
  if (!(flowM3H > 0)) throw new Error('Flow rate must be greater than zero.');
  if (!(headM > 0)) throw new Error('Head must be greater than zero.');
  if (!(speedRpm1 > 0)) throw new Error('Original speed must be greater than zero.');
  if (!(speedRpm2 > 0)) throw new Error('New speed must be greater than zero.');
  const ratio = speedRpm2 / speedRpm1;
  return {
    ratio,
    flowM3H2: flowM3H * ratio,
    headM2: headM * ratio * ratio,
    powerKw2: powerKw > 0 ? powerKw * ratio * ratio * ratio : null,
    note: 'Valid for a FIXED impeller diameter with speed as the only change (e.g. VFD speed adjustment) \u2014 a different relationship applies for impeller trimming at constant speed.',
  };
}

// ============================================================
// 2. FAN / BLOWER: AFFINITY LAWS & SHAFT POWER
// ============================================================

/** Same structural form as the pump affinity laws, for fan speed change at constant air density. */
export function fanAffinityLaws({ flowM3S, pressurePa, powerKw, speedRpm1, speedRpm2 }) {
  if (!(flowM3S > 0)) throw new Error('Flow rate must be greater than zero.');
  if (!(pressurePa > 0)) throw new Error('Pressure must be greater than zero.');
  if (!(speedRpm1 > 0)) throw new Error('Original speed must be greater than zero.');
  if (!(speedRpm2 > 0)) throw new Error('New speed must be greater than zero.');
  const ratio = speedRpm2 / speedRpm1;
  return {
    ratio,
    flowM3S2: flowM3S * ratio,
    pressurePa2: pressurePa * ratio * ratio,
    powerKw2: powerKw > 0 ? powerKw * ratio * ratio * ratio : null,
    note: 'Valid at constant air density \u2014 a significant temperature or altitude change between the two conditions invalidates this simple ratio.',
  };
}

/** Fan shaft (brake) power from flow, total pressure rise, and efficiency. */
export function fanShaftPower({ flowM3S, pressureRisePa, totalEfficiencyPct }) {
  if (!(flowM3S > 0)) throw new Error('Flow rate must be greater than zero.');
  if (!(pressureRisePa > 0)) throw new Error('Pressure rise must be greater than zero.');
  if (!(totalEfficiencyPct > 0 && totalEfficiencyPct <= 100)) throw new Error('Efficiency must be between 0 and 100%.');
  const aeroPowerKw = (flowM3S * pressureRisePa) / 1000;
  const shaftPowerKw = aeroPowerKw / (totalEfficiencyPct / 100);
  return { aeroPowerKw, shaftPowerKw };
}

// ============================================================
// 3. ROLLING ELEMENT BEARING L10 LIFE (ISO 281)
// ============================================================
//
//   L10 (millions of revolutions) = (C/P)^p
//   p = 3 for ball bearings, 10/3 for roller bearings
//   L10h (hours) = L10 * 1e6 / (60 * N)

export function bearingL10Life({ dynamicLoadRatingKn, equivalentLoadKn, bearingType = 'ball', speedRpm }) {
  if (!(dynamicLoadRatingKn > 0)) throw new Error('Dynamic load rating C must be greater than zero.');
  if (!(equivalentLoadKn > 0)) throw new Error('Equivalent dynamic load P must be greater than zero.');
  if (!(speedRpm > 0)) throw new Error('Rotational speed must be greater than zero.');
  if (!['ball', 'roller'].includes(bearingType)) throw new Error("Bearing type must be 'ball' or 'roller'.");
  const p = bearingType === 'ball' ? 3 : 10 / 3;
  const l10MillionRev = Math.pow(dynamicLoadRatingKn / equivalentLoadKn, p);
  const l10Hours = (l10MillionRev * 1e6) / (60 * speedRpm);
  return {
    exponentP: p, l10MillionRev, l10Hours,
    l10Years8760h: l10Hours / 8760,
    note: 'L10 is the life 90% of an identical population of bearings will exceed under this load \u2014 a statistical rating, not a guaranteed individual bearing life. Contamination, lubrication and misalignment can reduce actual life well below L10.',
  };
}

// ============================================================
// 4. PUMP HYDRAULIC / BRAKE / MOTOR POWER (ABSOLUTE, NOT SCALED)
// ============================================================
//
// The affinity laws above only SCALE a power value you already have from
// one speed to another. This calculates absolute power from first
// principles for a new duty point -- the calculation actually needed to
// size a motor for a pump that doesn't have a prior operating point to
// scale from.
//
//   Hydraulic power (W) = rho * g * Q * H
//   Brake power = hydraulic power / pump efficiency
//   Motor input power = brake power / motor efficiency

const G_GRAVITY = 9.80665; // m/s^2

export function pumpPower({ flowM3H, headM, specificGravity, pumpEfficiencyPct, motorEfficiencyPct }) {
  if (!(flowM3H > 0)) throw new Error('Flow rate must be greater than zero.');
  if (!(headM > 0)) throw new Error('Head must be greater than zero.');
  if (!(specificGravity > 0)) throw new Error('Specific gravity must be greater than zero.');
  if (!(pumpEfficiencyPct > 0 && pumpEfficiencyPct <= 100)) throw new Error('Pump efficiency must be between 0 and 100%.');
  const densityKgM3 = specificGravity * 1000;
  const flowM3S = flowM3H / 3600;
  const hydraulicPowerW = densityKgM3 * G_GRAVITY * flowM3S * headM;
  const brakePowerKw = (hydraulicPowerW / 1000) / (pumpEfficiencyPct / 100);
  let motorInputKw = null;
  if (motorEfficiencyPct !== undefined && motorEfficiencyPct !== null && motorEfficiencyPct !== '') {
    if (!(motorEfficiencyPct > 0 && motorEfficiencyPct <= 100)) throw new Error('Motor efficiency must be between 0 and 100%.');
    motorInputKw = brakePowerKw / (motorEfficiencyPct / 100);
  }
  return {
    hydraulicPowerKw: hydraulicPowerW / 1000,
    brakePowerKw,
    motorInputKw,
    note: 'Add a service factor / sizing margin per site practice before selecting an actual motor rating \u2014 this is the calculated duty point, not a motor nameplate recommendation.',
  };
}

// ============================================================
// 5. PUMP SPECIFIC SPEED (type/impeller selection guide)
// ============================================================
//
// Ns = N*sqrt(Q) / H^0.75 (US customary: N in rpm, Q in US gpm at best
// efficiency point, H in ft per stage) -- the standard dimensional
// specific speed used industry-wide to indicate impeller GEOMETRY family
// (radial/Francis/mixed/axial-flow), not an absolute performance rating.
// Different unit systems give numerically different Ns for the same
// physical pump; this uses the US customary form, the most commonly
// quoted in industry references and pump curves.

export function pumpSpecificSpeed({ speedRpm, flowGpm, headFt, numberOfStages = 1 }) {
  if (!(speedRpm > 0)) throw new Error('Pump speed must be greater than zero.');
  if (!(flowGpm > 0)) throw new Error('Flow rate (at best efficiency point) must be greater than zero.');
  if (!(headFt > 0)) throw new Error('Head must be greater than zero.');
  if (!(numberOfStages > 0)) throw new Error('Number of stages must be greater than zero.');
  const headPerStageFt = headFt / numberOfStages;
  const ns = (speedRpm * Math.sqrt(flowGpm)) / Math.pow(headPerStageFt, 0.75);

  let impellerType, note;
  if (ns < 1500) {
    impellerType = 'Radial flow';
    note = 'Low specific speed \u2014 typical of radial-flow impellers: high head, lower flow per stage. Common in multistage boiler feed and high-head process pumps.';
  } else if (ns < 4500) {
    impellerType = 'Mixed flow (Francis-type)';
    note = 'Mid-range specific speed \u2014 typical of general-purpose single-stage centrifugal pumps, the most common industrial pump type.';
  } else if (ns < 10000) {
    impellerType = 'Mixed flow (high)';
    note = 'Higher specific speed \u2014 lower head, higher flow per stage than a standard radial pump. Common in circulating water and low-head, high-flow service.';
  } else {
    impellerType = 'Axial flow (propeller)';
    note = 'Very high specific speed \u2014 typical of axial-flow (propeller) pumps: very high flow, low head. Common in flood control and large circulating water service.';
  }
  return {
    specificSpeedUS: ns, headPerStageFt, impellerType,
    note: `${note} This indicates the impeller geometry FAMILY typically used at this duty point \u2014 it is a selection guide, not a guarantee of which type a specific manufacturer will offer.`,
  };
}

// Adiabatic (isentropic) gas compressor power, ideal-gas relations. This
// is the standard shortcut method (Method 2 in the industry references):
// PVk = constant along an isentropic path, giving compression work per
// unit mass and the isentropic discharge temperature directly from inlet
// conditions, the pressure ratio, and the gas's specific heat ratio (k).
// A real compressor's actual discharge temperature runs hotter than the
// isentropic value because of irreversibilities -- captured here with an
// isentropic (adiabatic) efficiency, applied as extra work/heating rather
// than assuming a perfect process.
export function adiabaticCompressorPower({ p1Pa, p2Pa, t1K, k, molarMassKgPerKmol, massFlowKgS, efficiency = 1 }) {
  if (p1Pa <= 0 || p2Pa <= 0) throw new Error('Both pressures must be greater than zero (absolute).');
  if (p2Pa <= p1Pa) throw new Error('Discharge pressure must exceed suction pressure for a compressor.');
  if (t1K <= 0) throw new Error('Suction temperature must be a positive absolute temperature.');
  if (k <= 1) throw new Error('Specific heat ratio (k = Cp/Cv) must be greater than 1.');
  if (efficiency <= 0 || efficiency > 1) throw new Error('Efficiency must be between 0 (exclusive) and 1.');
  const R_UNIVERSAL = 8314.462618; // J/(kmol.K)
  const R = R_UNIVERSAL / molarMassKgPerKmol; // specific gas constant, J/(kg.K)
  const pressureRatio = p2Pa / p1Pa;
  const exponent = (k - 1) / k;
  const wIsentropicJKg = (k / (k - 1)) * R * t1K * (Math.pow(pressureRatio, exponent) - 1);
  const wActualJKg = wIsentropicJKg / efficiency;
  const t2IsentropicK = t1K * Math.pow(pressureRatio, exponent);
  const t2ActualK = t1K + (t2IsentropicK - t1K) / efficiency;
  const powerKW = (massFlowKgS * wActualJKg) / 1000;
  return { R, pressureRatio, wIsentropicJKg, wActualJKg, t2IsentropicK, t2ActualK, powerKW };
}
